import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

//combines tailwind class names together, auto-removing duplicates/conflicts
//pass any number of class strings/arrays/objects and get a merged string back
//usage: cn('foo', isRed && 'bg-red-500', 'p-4') -> only valid, merged classes
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
