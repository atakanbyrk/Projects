import { db } from '@/firebase';
import {
  collection,
  addDoc,
  doc,
  updateDoc,
  arrayUnion,
  serverTimestamp,
} from 'firebase/firestore';
import { getDoc } from 'firebase/firestore';

//creates a new empty custom workout plan for a user, stores to firestore and returns the doc id
export const createCustomWorkoutPlan = async (
  userId: string,
  name: string,
  description: string,
) => {
  //make new doc in 'customWorkoutPlans' collection with user id, name, desc, and empty ex array
  const docRef = await addDoc(collection(db, 'customWorkoutPlans'), {
    userId,
    name,
    description,
    createdAt: serverTimestamp(),
    exercises: [], //empty at start
  });
  //return the new doc's id so we can use it right away
  return docRef.id;
};

type ExerciseWithSets = {
  id: string;
  name: string;
  imageUrl: string;
  description: string;
  animationUrl?: string;
  setsReps: string;
};

//adds an exercise to a plan (does a check to avoid duplicates, throws err if already in plan)
//so first loads plan from db, checks if exercise is already there, if not then adds using arrayUnion (safe for firestore)
export const addExerciseToPlan = async (
  planId: string,
  exercise: ExerciseWithSets,
) => {
  //get plan doc ref
  const planRef = doc(db, 'customWorkoutPlans', planId);
  //get the data
  const planSnap = await getDoc(planRef);

  if (planSnap.exists()) {
    const planData = planSnap.data();
    const exercises = planData.exercises as ExerciseWithSets[];

    //check for dupe by id, if already there throw error
    const alreadyExists = exercises?.some((ex) => ex.id === exercise.id);
    if (alreadyExists) {
      throw new Error('Exercise already in plan');
    }

    //add exercise (arrayUnion makes sure if someone else adds at same time it doesn't mess up)
    await updateDoc(planRef, {
      exercises: arrayUnion(exercise),
    });
  }
};
