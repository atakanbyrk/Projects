import { useEffect, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth } from '@/firebase';

//react hook to track the current logged-in firebase user (or null if not signed in)
//subscribes to auth state change on mount, cleans up when unmounting, returns { user }
export function useUser() {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    //set up listener to auth state; fires on login, logout, or session changes
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser); //null if signed out
    });
    //return cleanup function to remove listener when component unmounts
    return () => unsubscribe();
  }, []);

  //returns current user object or null, always fresh
  return { user };
}
