//main landing page. shows logo, tagline, and lets user navigate to all major sections of the app.
//displays feature cards for each main page (exercises, plans, health, about), each with icon and short desc.

'use client';

import Link from 'next/link';
import Image from 'next/image';
import { useEffect, useState } from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import {
  Dumbbell,
  ClipboardList,
  HeartPulse,
  Users2,
  ArrowRight,
} from 'lucide-react';

//list of feature pages: each will be a card user can click
const features = [
  {
    title: 'Exercises',
    description: 'Browse detailed 3D calisthenics movements.',
    href: '/exercises',
    icon: Dumbbell,
  },
  {
    title: 'Workout Plans',
    description: 'Pick from beginner to expert routines built for progress.',
    href: '/workout-plans',
    icon: ClipboardList,
  },
  {
    title: 'Health',
    description: 'Learn recovery, nutrition, and injury prevention tips.',
    href: '/health',
    icon: HeartPulse,
  },
  {
    title: 'About Us',
    description: 'Meet the team behind Torqed and our mission.',
    href: '/aboutus',
    icon: Users2,
  },
];

export default function Home() {
  //controls whether to show skeletons while loading
  const [loading, setLoading] = useState(true);

  //little fake loading skeleton to make homepage feel more modern
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(t);
  }, []);

  return (
    <main className='flex flex-col items-center justify-center px-4 py-16 text-center'>
      {/* logo + tagline on top of image */}
      <div className='relative mb-8 w-full max-w-7xl'>
        <Image
          width={1800}
          height={1800}
          quality={100}
          src='/landing.png'
          alt='Calisthenics illustration'
          className='w-full rounded-sm border border-green-200 shadow-lg dark:border-neutral-800'
          priority
        />
        <div className='absolute inset-0 flex flex-col items-center justify-center rounded-sm bg-black/40'>
          <Image
            src='/logo.png'
            alt='Torqed Logo'
            width={180}
            height={60}
            className='mb-2'
            priority
          />
          <h1 className='sr-only'>Torqed Calisthenics App</h1>
          <p className='font-body mt-2 max-w-xl text-lg font-[var(--font-gill-sans-mt)] text-white drop-shadow'>
            Explore, learn, and master calisthenics. Track your progress and
            unlock expert-level tools.
          </p>
        </div>
      </div>

      {/* features grid: shows all main sections, or loading skeleton if loading */}
      <div className='grid w-full max-w-6xl grid-cols-1 gap-6 px-4 sm:grid-cols-2 lg:grid-cols-4'>
        {loading
          ? //show skeleton placeholders while loading (pretend to load content)
            Array(4)
              .fill(null)
              .map((_, i) => (
                <div
                  key={i}
                  className='rounded-xl border bg-white p-6 dark:bg-neutral-900'
                >
                  <Skeleton className='mx-auto mb-4 h-12 w-12 rounded-full' />
                  <Skeleton className='mx-auto mb-2 h-5 w-3/4' />
                  <Skeleton className='mx-auto h-4 w-2/3' />
                </div>
              ))
          : //once loaded, show actual features as cards with icon, title, desc, arrow
            features.map(({ title, description, href, icon: Icon }) => (
              <Link
                key={title}
                href={href}
                className='bg-card rounded-xl border p-6 transition-transform hover:scale-[1.02] hover:shadow-[0_6px_12px_0_#4E995C80]'
              >
                <div className='flex flex-col items-center gap-4 text-center'>
                  <Icon size={40} className='text-brand-green text-green-700' />
                  <h2 className='font-logo text-2xl'>{title}</h2>
                  <p className='font-body text-muted-foreground text-sm'>
                    {description}
                  </p>
                  <ArrowRight className='mt-2' />
                </div>
              </Link>
            ))}
      </div>

      {/* button to dashboard at bottom */}
      <div className='mt-16'>
        <Button asChild className='font-logo bg-green-600'>
          <Link href='/dashboard'>Go to Dashboard</Link>
        </Button>
      </div>
    </main>
  );
}
