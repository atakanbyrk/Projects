// exercise page: loads all exercises from Firestore, supports filtering + pagination
'use client';

import { useEffect, useState } from 'react';
import { db } from '@/firebase';
import {
  collection,
  getDocs,
  QueryDocumentSnapshot,
  DocumentData,
} from 'firebase/firestore';
import Filter from './components/filter';
import { ExerciseCard } from './components/exerciseCard';
import { Ban } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination';

// exercise type shape used across the app
export type Exercise = {
  id: string;
  name: string;
  level: string;
  musclesWorked: string[];
  description: string;
  difficulty: number;
  animationUrl: string;
  imageUrl?: string;
};

export default function ExercisesPage() {
  //all exercise data fetched from firestore
  const [exercises, setExercises] = useState<Exercise[]>([]);

  //true while we're waiting on the db response
  const [loading, setLoading] = useState(true);

  //populates dropdowns for filtering UI
  const [filterOptions, setFilterOptions] = useState({
    level: ['All'],
    muscle: ['All'],
    difficulty: ['0'],
  });

  //holds selected filter values
  const [filter, setFilter] = useState({
    level: 'All',
    muscle: 'All',
    search: '',
    difficulty: 'All',
  });

  //final filtered results after applying filters
  const [filteredExcercises, setFilteredExcercises] = useState<Exercise[]>([]);

  //pagination logic
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  //on mount: fetch all exercise documents from firestore
  useEffect(() => {
    const fetchExercises = async () => {
      const querySnapshot = await getDocs(collection(db, 'exercises'));

      //map each doc to our Exercise type
      const data = querySnapshot.docs.map(mapDocToExercise);

      setExercises(data);
      setFilterOptions(generateFilterOptions(data));
      setLoading(false);
    };

    fetchExercises();
  }, []);

  //helper: convert firestore doc to our Exercise type
  const mapDocToExercise = (
    doc: QueryDocumentSnapshot<DocumentData>,
  ): Exercise =>
    ({
      id: doc.id,
      ...doc.data(),
    }) as Exercise;

  //generates dropdown options for filters based on loaded exercise data
  //extracts unique values for level, muscle group, and difficulty
  //adds "All" to start so users can reset the filter
  const generateFilterOptions = (data: Exercise[]) => {
    const levels = extractUniqueSortedValues(data, (ex) => ex.level);

    const muscles = extractUniqueSortedValues(
      data,
      (ex) => ex.musclesWorked, // note: this handles arrays like ['biceps', 'core']
    ).sort();

    const difficulties = extractUniqueSortedValues(data, (ex) =>
      ex.difficulty.toString(),
    ).sort((a, b) => parseInt(a) - parseInt(b)); //make sure difficulty sorts numerically not alphabetically

    return {
      level: ['All', ...levels],
      muscle: ['All', ...muscles],
      difficulty: ['All', ...difficulties],
    };
  };

  //takes an array of data and a selector function to extract values
  //it flattens the output in case the selector returns arrays (like musclesWorked),
  //then removes duplicates using a Set and returns a sorted list
  //used for generating clean filter dropdowns without repetition
  const extractUniqueSortedValues = <T, K>(
    data: T[],
    selector: (item: T) => K | K[],
  ): K[] => {
    // map each item to the selected value(s), flatten to handle array values like ['Back', 'Biceps']
    const values = data.flatMap((item) => selector(item));

    // convert to a Set to remove duplicates, then turn it back into an array and sort alphabetically
    return Array.from(new Set(values)).sort();
  };

  //watch for changes to filters or exercises, apply filters to dataset
  //filters by: level, musclesWorked, search text, difficulty score
  //then resets pagination to first page
  useEffect(() => {
    const filtered = exercises.filter((exercise) => {
      const matchesLevel =
        filter.level === 'All' || exercise.level === filter.level;

      const matchesMuscle =
        filter.muscle === 'All' ||
        exercise.musclesWorked.includes(filter.muscle);

      const matchesSearch = exercise.name
        .toLowerCase()
        .includes(filter.search.toLowerCase());

      const matchesDifficulty =
        filter.difficulty === 'All' ||
        (!isNaN(Number(filter.difficulty)) &&
          exercise.difficulty === Number(filter.difficulty));

      return (
        matchesLevel && matchesMuscle && matchesSearch && matchesDifficulty
      );
    });

    setFilteredExcercises(filtered);
    setCurrentPage(1); //reset to first page on filter change
  }, [exercises, filter]);

  //basic pagination logic, splits filtered results into chunks per page
  //slices array to only show current page's exercises
  const totalPages = Math.ceil(filteredExcercises.length / itemsPerPage);
  const paginated = filteredExcercises.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage,
  );

  if (loading)
    return <div className='p-10 text-center'>Loading exercises...</div>;

  return (
    <main className='mx-auto p-8'>
      <h1 className='font-logo mb-6 text-center text-3xl'>
        Exercise Library
      </h1>

      <div className='font-body bg-card mb-8 flex w-full flex-col justify-center gap-2 rounded-lg border px-4 py-2 shadow lg:flex-row'>
        <Filter
          filter={filter}
          filterOptions={filterOptions}
          onFilterChange={setFilter}
        />
      </div>

      {filteredExcercises.length > 0 ? (
        <>
          <div className='grid auto-rows-auto grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4'>
            {paginated.map((excercise) => (
              <ExerciseCard key={excercise.id} excercise={excercise} />
            ))}
          </div>

          <Pagination className='mt-10'>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious
                  href='#'
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  aria-disabled={currentPage === 1}
                />
              </PaginationItem>

              {Array.from({ length: totalPages }).map((_, i) => (
                <PaginationItem key={i}>
                  <PaginationLink
                    isActive={i + 1 === currentPage}
                    onClick={() => setCurrentPage(i + 1)}
                  >
                    {i + 1}
                  </PaginationLink>
                </PaginationItem>
              ))}

              <PaginationItem>
                <PaginationNext
                  href='#'
                  onClick={() =>
                    setCurrentPage((p) => Math.min(totalPages, p + 1))
                  }
                  aria-disabled={currentPage === totalPages}
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </>
      ) : (
        <Alert
          variant='destructive'
          className='mx-auto mt-10 max-w-md text-left'
        >
          <Ban className='mx-auto h-6 w-6 text-red-500' />
          <AlertTitle className='mt-2 text-lg font-logo text-red-600'>
            No Exercises Found
          </AlertTitle>
          <AlertDescription className='font-body text-muted-foreground text-sm'>
            Try adjusting your filters or changing the search term. We
            couldn&apos;t find anything matching your criteria.
          </AlertDescription>
        </Alert>
      )}
    </main>
  );
}
