import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import React from 'react';

//type that holds the available filter values (used to populate dropdowns)
type FilterOptions = {
  level: string[];
  muscle: string[];
  difficulty: string[];
};

//type that holds current selected filter state
type Filter = {
  level: string;
  muscle: string;
  search: string;
  difficulty: string;
};

//props accepted by the filter component
type Props = {
  filterOptions: FilterOptions; // all the options we can choose from
  filter: Filter; // current selected filter values
  onFilterChange: React.Dispatch<React.SetStateAction<Filter>>; // state update fn
};

//keys from FilterOptions we want to render as selects
const selectFilters: (keyof FilterOptions)[] = [
  'level',
  'muscle',
  'difficulty',
];

//this component renders the filtering controls for the exercise list
const Filter: React.FC<Props> = ({ filterOptions, filter, onFilterChange }) => {
  //helper to generate each dropdown with its label and items
  const filterSelectRenderer = (filterType: string) => {
    const filterTypeKey = filterType as keyof FilterOptions;

    return (
      <div
        key={filterType}
        className='flex flex-col items-start gap-1 sm:flex-row sm:items-center sm:gap-1.5'
      >
        {/* label for the select dropdown */}
        <Label htmlFor={filterType} className='shrink-0 text-sm font-medium'>
          {filterType.charAt(0).toUpperCase() + filterType.slice(1)}:
        </Label>

        {/* the dropdown for selecting a filter value */}
        <Select
          value={filter[filterTypeKey]}
          onValueChange={(value) =>
            onFilterChange((prev) => ({ ...prev, [filterType]: value }))
          }
        >
          <SelectTrigger id={filterType} className='w-[160px]'>
            <SelectValue placeholder={`Select ${filterType}`} />
          </SelectTrigger>
          <SelectContent>
            {filterOptions[filterTypeKey].map((item) => (
              <SelectItem key={item} value={item}>
                {item}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    );
  };

  return (
    // container for all filter controls (dropdowns + search)
    <div className='flex flex-wrap justify-center gap-4'>
      {/* render dropdowns for level, muscle, difficulty */}
      {selectFilters.map((filterType) => filterSelectRenderer(filterType))}

      {/* text input for name search */}
      <div className='flex flex-col items-start gap-1 sm:flex-row sm:items-center sm:gap-1.5'>
        <Label htmlFor='search' className='shrink-0 text-sm font-medium'>
          Search:
        </Label>
        <Input
          id='search'
          className='w-[160px]'
          type='text'
          placeholder='Search by name'
          value={filter.search}
          onChange={(e) =>
            onFilterChange((prev) => ({ ...prev, search: e.target.value }))
          }
        />
      </div>
    </div>
  );
};

export default Filter;
