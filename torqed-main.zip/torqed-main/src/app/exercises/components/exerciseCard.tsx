'use client';

import GLBViewer from '@/components/custom/GLBViewer';
import { Skeleton } from '@/components/ui/skeleton';
import Image from 'next/image';
import React, { useEffect, useRef, useState } from 'react';
import { Exercise } from '../page';
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { ExerciseModalTrigger } from './exerciseModalTrigger';
import AddToWorkoutModal from '@/components/custom/addToWorkoutModal';

import { useUser } from '@/lib/hooks/useUser'; //custom hook to get firebase user
import { useRouter } from 'next/navigation'; //for redirecting user if needed
import { toast } from 'sonner'; //toast for feedback

// card displaying each exercise with 3D view, add-to-plan button and modal
type Props = {
  excercise: Exercise;
};

export const ExerciseCard: React.FC<Props> = ({ excercise }) => {
  const [show3D, setShow3D] = useState(false); // controls if 3D model is shown
  const ref = useRef<HTMLDivElement | null>(null); // ref to track visibility
  const [isMobile, setIsMobile] = useState(false); // check if user is on mobile
  const [showAddModal, setShowAddModal] = useState(false); // modal for adding to custom workout

  const { user } = useUser(); // get firebase user
  const router = useRouter(); // router for redirects if needed

  // check on first load and window resize if we’re on mobile
  useEffect(() => {
    const mobileCheck = () => {
      const nowMobile = window.innerWidth < 768;
      setIsMobile((prevMobile) => {
        if (prevMobile && !nowMobile) {
          // if switching from mobile to desktop, stop 3D viewer
          setShow3D(false);
        }
        return nowMobile;
      });
    };

    mobileCheck(); // do initial check
    window.addEventListener('resize', mobileCheck); // listen for screen size change
    return () => window.removeEventListener('resize', mobileCheck);
  }, []);

  // on mobile: wait until user scrolls near component, then show 3D
  useEffect(() => {
    if (!isMobile) return;

    let timeout: NodeJS.Timeout;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          // delay before showing 3D to save perf
          timeout = setTimeout(() => setShow3D(true), 2500);
        } else {
          clearTimeout(timeout);
        }
      },
      { threshold: 0.7 }, // 70% visible before loading 3D
    );

    // Get the node (DOM element) to be observed from the ref
    const observedNode = ref.current;

    // If the node exists, start observing it with the IntersectionObserver
    if (observedNode) observer.observe(observedNode);

    return () => {
      // Clean up any previously set timeout when the effect re-runs or unmounts
      clearTimeout(timeout);

      // Stop observing the node to prevent memory leaks or duplicate observation
      if (observedNode) observer.unobserve(observedNode);
    };
  }, [isMobile]);

  const hasImage = !!excercise.imageUrl;
  const hasGLB = !!excercise.animationUrl;

  return (
    <Card
      key={excercise.id}
      className='group mb-4 transition-transform duration-200 hover:scale-105 hover:shadow-lg'
    >
      <CardHeader className='font-logo'>
        <div className='flex w-full items-center justify-between'>
          <h2 className='line-clamp-2 max-w-[70%] pr-2 text-xl leading-snug break-words'>
            {excercise.name}
          </h2>
          <div className='ml-auto flex items-center'>
            <Button
              variant='ghost'
              size='sm'
              className='h-8 w-8 p-0'
              onClick={() => {
                if (!user) {
                  toast.error('You must be logged in to add exercises');
                  router.push('/login'); // or '/signin' depending on your route
                  return;
                }
                setShowAddModal(true);
              }}
            >
              <Plus fill='red' color='red' size={18} />
            </Button>

            {!isMobile && hasGLB && (
              <ExerciseModalTrigger exercise={excercise} />
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent>
        {hasImage && hasGLB ? (
          <div
            ref={ref}
            className='relative mb-2 h-64 w-full overflow-hidden rounded'
          >
            <Image
              src={excercise.imageUrl || '/fallback-image.png'}
              alt={excercise.name}
              fill
              sizes='(max-width: 768px) 100vw, 50vw'
              className={`object-cover transition-opacity duration-300 ${
                show3D ? 'opacity-0' : 'opacity-100'
              }`}
            />
            {show3D && isMobile && (
              <div className='absolute inset-0 z-10 bg-white dark:bg-neutral-900'>
                <GLBViewer url={excercise.animationUrl!} />
              </div>
            )}
          </div>
        ) : hasImage ? (
          <Image
            src={excercise.imageUrl || '/fallback-image.png'}
            alt={excercise.name}
            width={320}
            height={128}
            className='mb-2 h-64 w-full rounded object-cover'
          />
        ) : hasGLB && isMobile ? (
          <div ref={ref} className='mb-2 h-64 w-full overflow-hidden rounded'>
            {show3D ? (
              <GLBViewer url={excercise.animationUrl!} />
            ) : (
              <Skeleton className='h-full w-full rounded bg-gray-200' />
            )}
          </div>
        ) : hasGLB && !isMobile ? (
          <Image
            src={excercise.imageUrl || '/fallback-image.png'}
            alt={excercise.name}
            width={320}
            height={128}
            className='mb-2 h-64 w-full rounded object-cover'
          />
        ) : (
          <Skeleton className='mb-2 h-64 w-full rounded bg-gray-200' />
        )}
      </CardContent>

      <CardFooter className='font-body flex flex-col items-start'>
        <div className='text-m mb-1'>
          <span className='font-logo text-yellow-400'>Level:</span>{' '}
          {excercise.level}
          <br />
          <span className='font-logo text-red-400'>Difficulty Score:</span>{' '}
          {excercise.difficulty}/5
          <br />
          <span className='font-logo text-green-400'>Muscles:</span>{' '}
          {excercise.musclesWorked.join(', ')}
        </div>
        <p className='font-body mt-2 text-gray-600 dark:text-gray-300'>
          {excercise.description}
        </p>
      </CardFooter>
      <AddToWorkoutModal
        open={showAddModal}
        onOpenChange={setShowAddModal}
        exercise={{
          id: excercise.id,
          name: excercise.name,
          imageUrl: excercise.imageUrl || '',
          description: excercise.description,
          animationUrl: excercise.animationUrl || '',
        }}
      />
    </Card>
  );
};
