'use client';

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Exercise } from '@/app/exercises/page';
import GLBViewer from '@/components/custom/GLBViewer';
import Image from 'next/image';

type Props = {
  exercise: Exercise;
};

export function ExerciseModalTrigger({ exercise }: Props) {
  const [isOpen, setIsOpen] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setMounted(true);
    } else {
      // Delay unmounting slightly to allow dialog animation to finish
      const timeout = setTimeout(() => setMounted(false), 200);
      return () => clearTimeout(timeout);
    }
  }, [isOpen]);

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant='outline' size='sm'>
          View
        </Button>
      </DialogTrigger>
      <DialogContent className='max-h-[95vh] w-full max-w-4xl overflow-y-auto md:max-w-5xl lg:max-w-6xl'>
        <DialogHeader>
          <DialogTitle className='font-logo text-xl text-green-600 sm:text-2xl md:text-3xl'>
            {exercise.name}
          </DialogTitle>
        </DialogHeader>

        <div className='flex flex-col gap-6 py-4 md:flex-row md:gap-8 lg:gap-10'>
          <div className='h-auto min-h-[300px] w-full sm:min-h-[350px] md:min-h-[400px] md:w-1/2 lg:min-h-[450px]'>
            {mounted && exercise.animationUrl ? (
              <div className='h-full w-full'>
                <GLBViewer url={exercise.animationUrl} />
              </div>
            ) : exercise.imageUrl ? (
              <div className='relative aspect-square w-full md:aspect-auto md:h-full'>
                <Image
                  src={exercise.imageUrl}
                  alt={exercise.name}
                  fill
                  className='rounded-md object-contain shadow'
                />
              </div>
            ) : (
              <div className='bg-muted flex h-full w-full items-center justify-center rounded-md'>
                <p className='text-muted-foreground text-xl'>
                  No media available.
                </p>
              </div>
            )}
          </div>

          <div className='w-full space-y-4 md:w-1/2 md:space-y-6'>
            <div className='grid grid-cols-2 gap-3'>
              <div className='bg-muted rounded-md p-3 shadow-sm'>
                <p>
                  <span className='font-logo text-base text-yellow-500 sm:text-lg'>
                    Level:
                  </span>{' '}
                  <span className='font-body mt-2 block text-base'>{exercise.level}</span>
                </p>
              </div>
              <div className='bg-muted rounded-md p-3 shadow-sm'>
                <p>
                  <span className='font-logo text-base text-red-500 sm:text-lg'>
                    Difficulty:
                  </span>{' '}
                  <span className='font-body mt-2 block text-base'>
                    {exercise.difficulty}/5
                  </span>
                </p>
              </div>
            </div>

            <div className='bg-muted rounded-md p-3 shadow-sm'>
              <p>
                <span className='font-logo text-base text-green-500 sm:text-lg'>
                  Muscles:
                </span>{' '}
                <span className='font-body mt-2 block text-base'>
                  {exercise.musclesWorked.join(', ')}
                </span>
              </p>
            </div>

            <div className='mt-6'>
              <p className='font-body text-muted-foreground text-base leading-relaxed md:text-lg'>
                {exercise.description}
              </p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}