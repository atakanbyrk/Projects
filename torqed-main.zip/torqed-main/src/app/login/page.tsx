//login/auth page for the app. handles both login and signup with email/pass + google, shows tabs, validation and inline error messages

'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { auth, db } from '@/firebase';
import {
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signInWithPopup,
  createUserWithEmailAndPassword,
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { ZodError } from 'zod';
import { formSchema, signUpSchema } from './formSchema';

export default function AuthPage() {
  //handles page routing/navigation
  const router = useRouter();

  //which tab is open (login/signup)
  const [tab, setTab] = useState('login');

  //errors for login inputs, each field can have own error message from zod
  const [loginErrors, setLoginErrors] = useState<{
    email?: string;
    password?: string;
  }>({});

  //holds login form state (email/pass)
  const [loginData, setLoginData] = useState({ email: '', password: '' });

  //holds signup form state (name, surname, etc)
  const [signUpData, setSignUpData] = useState({
    name: '',
    surname: '',
    email: '',
    password: '',
  });

  //errors for sign up inputs, same as login, set on zod fail
  const [signUpErrors, setSignUpErrors] = useState<{
    name?: string;
    surname?: string;
    email?: string;
    password?: string;
  }>({});

  //called when user clicks login, validates with zod and shows errors inline
  const handleLogin = async () => {
    try {
      //parse+validate with zod, throws if invalid
      formSchema.parse(loginData);
      setLoginErrors({}); //clear old errors

      //actually try firebase login
      await signInWithEmailAndPassword(
        auth,
        loginData.email,
        loginData.password,
      );
      router.push('/dashboard');
    } catch (err) {
      if (err instanceof ZodError) {
        //get error for each field and show under input
        const fieldErrors = err.flatten().fieldErrors;
        setLoginErrors({
          email: fieldErrors.email?.[0],
          password: fieldErrors.password?.[0],
        });
      } else {
        //firebase or network error etc
        console.error(err);
      }
    }
  };

  //signup button click handler, validates with zod, makes user in firebase, adds user doc in firestore
  const handleSignUp = async () => {
    try {
      signUpSchema.parse(signUpData); //zod validate
      setSignUpErrors({}); //clear old errors

      //firebase create account
      const result = await createUserWithEmailAndPassword(
        auth,
        signUpData.email,
        signUpData.password,
      );
      //create user profile in firestore
      await setDoc(doc(db, 'users', result.user.uid), {
        name: signUpData.name,
        surname: signUpData.surname,
        email: signUpData.email,
        photoURL: '',
        createdAt: serverTimestamp(),
      });
      router.push('/dashboard');
    } catch (err) {
      if (err instanceof ZodError) {
        //set error msg for each field so we show under box
        const fieldErrors = err.flatten().fieldErrors;
        setSignUpErrors({
          name: fieldErrors.name?.[0],
          surname: fieldErrors.surname?.[0],
          email: fieldErrors.email?.[0],
          password: fieldErrors.password?.[0],
        });
      } else {
        //firebase/signup error
        toast.error('Sign up failed');
        console.error(err);
      }
    }
  };

  //handles login/signup with google, if new user creates doc, if already exists does nothing
  const handleGoogleLogin = async () => {
    const provider = new GoogleAuthProvider();
    const result = await signInWithPopup(auth, provider);
    const user = result.user;
    const userRef = doc(db, 'users', user.uid);
    const userSnap = await getDoc(userRef);

    if (!userSnap.exists()) {
      //only add profile if not exists
      await setDoc(userRef, {
        name: user.displayName || '',
        email: user.email || '',
        photoURL: user.photoURL || '',
        createdAt: serverTimestamp(),
      });
    }

    router.push('/dashboard');
  };

  //runs when component mounts, checks if user already logged in and redirects to dashboard
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      if (user) router.push('/dashboard');
    });
    return () => unsub();
  }, [router]);

  return (
    <div className='mx-auto mt-20 w-full max-w-md'>
      {/*tabs: toggles between login and signup forms*/}
      <Tabs value={tab} onValueChange={setTab} className='w-full'>
        <TabsList className='grid w-full grid-cols-2'>
          <TabsTrigger value='login'>Login</TabsTrigger>
          <TabsTrigger value='signup'>Sign Up</TabsTrigger>
        </TabsList>

        {/*login tab: handles login with email/password or google*/}
        <TabsContent value='login'>
          <Card>
            <CardHeader>
              <CardTitle>Login</CardTitle>
              <CardDescription>Access your account</CardDescription>
            </CardHeader>
            <CardContent className='space-y-2'>
              <div className='space-y-1'>
                <Label htmlFor='email'>Email</Label>
                <Input
                  id='email'
                  placeholder='Email'
                  type='email'
                  value={loginData.email}
                  onChange={(e) =>
                    setLoginData({ ...loginData, email: e.target.value })
                  }
                  className={loginErrors.email ? 'border-red-500' : ''}
                />
                {/*shows validation error under box*/}
                {loginErrors.email && (
                  <p className='text-sm text-red-500'>{loginErrors.email}</p>
                )}
              </div>
              <div className='space-y-1'>
                <Label htmlFor='password'>Password</Label>
                <Input
                  id='password'
                  placeholder='Password'
                  type='password'
                  value={loginData.password}
                  onChange={(e) =>
                    setLoginData({ ...loginData, password: e.target.value })
                  }
                  className={loginErrors.password ? 'border-red-500' : ''}
                />
                {loginErrors.password && (
                  <p className='text-sm text-red-500'>{loginErrors.password}</p>
                )}
              </div>
            </CardContent>
            <CardFooter className='flex flex-col gap-2'>
              <Button className='w-full' onClick={handleLogin}>
                Login
              </Button>
              <Button
                variant='outline'
                className='w-full'
                onClick={handleGoogleLogin}
              >
                Sign in with Google
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/*sign up tab: creates new user, uses inline validation*/}
        <TabsContent value='signup'>
          <Card>
            <CardHeader>
              <CardTitle>Sign Up</CardTitle>
              <CardDescription>Create a new account</CardDescription>
            </CardHeader>
            <CardContent className='space-y-2'>
              {/* name */}
              <div className='space-y-1'>
                <Label htmlFor='name'>Name</Label>
                <Input
                  id='name'
                  placeholder='Name'
                  value={signUpData.name}
                  onChange={(e) =>
                    setSignUpData({ ...signUpData, name: e.target.value })
                  }
                  className={signUpErrors.name ? 'border-red-500' : ''}
                />
                {signUpErrors.name && (
                  <p className='text-sm text-red-500'>{signUpErrors.name}</p>
                )}
              </div>
              {/* surname */}
              <div className='space-y-1'>
                <Label htmlFor='surname'>Surname</Label>
                <Input
                  id='surname'
                  placeholder='Surname'
                  value={signUpData.surname}
                  onChange={(e) =>
                    setSignUpData({ ...signUpData, surname: e.target.value })
                  }
                  className={signUpErrors.surname ? 'border-red-500' : ''}
                />
                {signUpErrors.surname && (
                  <p className='text-sm text-red-500'>{signUpErrors.surname}</p>
                )}
              </div>
              {/* email */}
              <div className='space-y-1'>
                <Label htmlFor='email'>Email</Label>
                <Input
                  id='email'
                  placeholder='Email'
                  type='email'
                  value={signUpData.email}
                  onChange={(e) =>
                    setSignUpData({ ...signUpData, email: e.target.value })
                  }
                  className={signUpErrors.email ? 'border-red-500' : ''}
                />
                {signUpErrors.email && (
                  <p className='text-sm text-red-500'>{signUpErrors.email}</p>
                )}
              </div>
              {/* password */}
              <div className='space-y-1'>
                <Label htmlFor='password'>Password</Label>
                <Input
                  id='password'
                  placeholder='Password'
                  type='password'
                  value={signUpData.password}
                  onChange={(e) =>
                    setSignUpData({ ...signUpData, password: e.target.value })
                  }
                  className={signUpErrors.password ? 'border-red-500' : ''}
                />
                {signUpErrors.password && (
                  <p className='text-sm text-red-500'>
                    {signUpErrors.password}
                  </p>
                )}
              </div>
            </CardContent>
            <CardFooter className='flex flex-col gap-2'>
              <Button className='w-full' onClick={handleSignUp}>
                Sign Up
              </Button>
              <Button
                variant='outline'
                className='w-full'
                onClick={handleGoogleLogin}
              >
                Sign up with Google
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
