'use client';

import { z } from 'zod';

const formSchema = z.object({
  email: z.string().min(2).email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters long'),
});

export const signUpSchema = z.object({
  name: z.string().min(2, "Name is required"),
  surname: z.string().min(2, "Surname is required"),
  email: z.string().min(2).email("Please enter a valid email"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export { formSchema };
