'use client';

import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import HealthSidebar from '@/components/custom/healthSidebar';
import HealthDropdown from '@/components/custom/healthDropdown';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

//this is the health tips main page. user can navigate through sidebar or dropdown.
//the sections explain warm-up, recovery, progression, gear etc. for calisthenics.
export default function HealthPage() {
  return (
    <main className='relative mx-auto min-h-screen max-w-7xl scroll-smooth px-4 py-10'>
      {/* responsive dropdown nav shown on small screens */}
      <HealthDropdown />

      <div className='flex flex-col lg:flex-row'>
        {/* sticky sidebar shown on desktop */}
        <HealthSidebar />

        {/* right main content area */}
        <div className='space-y-12 pl-0 lg:w-3/4 lg:pl-10'>
          {/* hero header */}
          <header>
            <h1 className='font-logo mb-2 text-4xl text-green-600'>
              Tips & Tricks and Health
            </h1>
            <p className='text-muted-foreground text-sm sm:text-base'>
              Your guide to training smarter, recovering better, and progressing
              faster in your calisthenics journey.
            </p>
          </header>

          <Separator className='my-10' />

          {/* section: pre-workout advice */}
          <section
            id='preworkout'
            className='rounded-xl bg-gradient-to-br from-green-50/60 to-green-100/40 p-6 shadow dark:from-green-950/60 dark:to-green-900/40'
          >
            <h2 className='mb-3 text-2xl font-bold text-green-700 dark:text-green-300'>
              Pre-Workout: Dynamic vs. Static Stretching
            </h2>
            <div className='space-y-4 text-sm'>
              <p>
                <span className='font-semibold text-green-700 dark:text-green-300'>
                  Dynamic stretching
                </span>{' '}
                is essential before every session, while{' '}
                <span className='font-semibold text-red-600 dark:text-red-400'>
                  static stretching
                </span>{' '}
                should be avoided pre-workout for optimal performance and
                safety.
              </p>

              <div className='grid grid-cols-1 gap-8 md:grid-cols-2'>
                <div className='rounded-lg bg-green-100 p-4 dark:bg-green-900/20'>
                  <h3 className='mb-2 font-semibold text-green-800 dark:text-green-300'>
                    Why Choose Dynamic Stretching?
                  </h3>
                  <ul className='list-inside list-disc space-y-1 text-green-900 dark:text-green-100'>
                    <li>Boosts blood flow and warms up muscles efficiently.</li>
                    <li>
                      Activates the nervous system for improved coordination.
                    </li>
                    <li>Prepares joints and tendons for load and movement.</li>
                    <li>
                      Enhances range of motion while maintaining muscle
                      readiness.
                    </li>
                  </ul>
                  <p className='mt-2 text-xs text-green-800 dark:text-green-300'>
                    <span className='font-medium'>Examples:</span> Arm circles,
                    hip openers, scapula pulls, banded dislocates.
                  </p>
                </div>
                <div className='rounded-lg bg-red-50/60 p-4 dark:bg-red-900/20'>
                  <h3 className='mb-2 font-semibold text-red-600 dark:text-red-400'>
                    Why Avoid Static Stretching Before?
                  </h3>
                  <ul className='list-inside list-disc space-y-1 text-red-900 dark:text-red-100'>
                    <li>Temporarily decreases muscle strength and power.</li>
                    <li>Slows reaction time and reduces explosiveness.</li>
                    <li>
                      Can compromise joint stability—especially important for
                      calisthenics.
                    </li>
                  </ul>
                </div>
              </div>

              <div className='mt-4 rounded bg-green-100 px-4 py-2 text-green-800 dark:bg-green-900 dark:text-green-200'>
                <strong>Key takeaway:</strong> Use dynamic stretching to prepare
                your body before training, and reserve static stretching for
                your post-workout routine.
              </div>
            </div>
          </section>

          <Separator className='my-10' />

          {/* section: post-workout recovery */}
          <section
            id='postworkout'
            className='rounded-xl bg-gradient-to-br from-green-50/60 to-green-100/40 p-6 shadow dark:from-green-950/60 dark:to-green-900/40'
          >
            <h2 className='mb-3 text-2xl font-bold text-green-700 dark:text-green-300'>
              Post-Workout: Why Static Stretching Matters
            </h2>
            <div className='space-y-4 text-sm'>
              <ul className='list-inside list-disc space-y-1'>
                <li>
                  <span className='font-semibold text-green-700 dark:text-green-300'>
                    Muscle recovery:
                  </span>{' '}
                  Relaxes the body and reduces muscle tension.
                </li>
                <li>
                  <span className='font-semibold text-green-700 dark:text-green-300'>
                    Flexibility gains:
                  </span>{' '}
                  Over time, static holds improve flexibility.
                </li>
                <li>
                  <span className='font-semibold text-green-700 dark:text-green-300'>
                    Better sleep &amp; reduced soreness:
                  </span>{' '}
                  Helps with sleep quality and reduces DOMS.
                </li>
              </ul>
              <div className='mt-2 flex flex-wrap gap-2 text-xs'>
                <span className='rounded bg-green-100 px-2 py-0.5 text-green-800 dark:bg-green-900 dark:text-green-200'>
                  Cobra pose
                </span>
                <span className='rounded bg-green-100 px-2 py-0.5 text-green-800 dark:bg-green-900 dark:text-green-200'>
                  Pigeon pose
                </span>
                <span className='rounded bg-green-100 px-2 py-0.5 text-green-800 dark:bg-green-900 dark:text-green-200'>
                  Chest T-stretch
                </span>
                <span className='rounded bg-green-100 px-2 py-0.5 text-green-800 dark:bg-green-900 dark:text-green-200'>
                  Wall lat stretch
                </span>
              </div>
            </div>
          </section>

          <Separator className='my-10' />

          {/* section: skill progression strategy */}
          <section
            id='progression'
            className='rounded-xl bg-gradient-to-br from-green-50/60 to-green-100/40 p-6 shadow dark:from-green-950/60 dark:to-green-900/40'
          >
            <h2 className='mb-3 text-2xl font-bold text-green-700 dark:text-green-300'>
              How to Progress in Calisthenics Skills
            </h2>
            <div className='space-y-4 text-sm'>
              <ul className='list-inside list-disc space-y-2'>
                <li>
                  <span className='font-semibold text-green-700 dark:text-green-300'>
                    Use resistance bands
                  </span>{' '}
                  for assistance with skills like front lever, planche, or
                  pull-ups.
                </li>
                <li>
                  <span className='font-semibold text-green-700 dark:text-green-300'>
                    Where to attach bands:
                  </span>
                  <ul className='mt-1 ml-6 list-disc space-y-1 text-green-900 dark:text-green-200'>
                    <li>
                      <span className='font-medium'>Front Lever:</span> Around
                      bar and under lower back
                    </li>
                    <li>
                      <span className='font-medium'>Planche variations:</span>{' '}
                      Under hips or legs
                    </li>
                  </ul>
                </li>
                <li>
                  <span className='font-semibold text-green-700 dark:text-green-300'>
                    Hold positions
                  </span>{' '}
                  for <span className='font-medium'>10-15 seconds</span> with
                  good form before progressing.
                </li>
                <li>
                  For reps-based skills, aim for{' '}
                  <span className='font-medium'>8-12 clean reps</span> before
                  moving to a harder variation.
                </li>
              </ul>
            </div>
          </section>

          <Separator className='my-10' />

          {/* section: recommended equipment with custom UI table */}
          <section id='equipment'>
            <h2 className='mb-3 text-2xl font-bold text-green-700 dark:text-green-300'>
              Useful Equipment for Calisthenics Training
            </h2>
            <p className='text-muted-foreground mb-4 text-sm'>
              While calisthenics is minimal by nature, a few key tools can
              enhance your training, support progression, and help prevent
              injury.
            </p>
            <div className='overflow-x-auto rounded-xl border border-green-100 bg-gradient-to-br from-green-50/60 to-green-100/40 p-0 shadow dark:border-green-900/40 dark:from-green-950/60 dark:to-green-900/40'>
              <Table className='text-sm'>
                <TableHeader>
                  <TableRow className='bg-green-100/60 dark:bg-green-900/30'>
                    <TableHead className='w-1/4 px-6 py-3 font-semibold text-green-800 dark:text-green-200'>
                      Equipment
                    </TableHead>
                    <TableHead className='px-6 py-3 font-semibold text-green-800 dark:text-green-200'>
                      Benefits &amp; Use Cases
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow className='transition hover:bg-green-50/80 dark:hover:bg-green-900/10'>
                    <TableCell className='w-1/4 px-6 py-4 align-top font-semibold text-green-900 dark:text-green-100'>
                      Parallettes
                      <div className='mt-1 text-xs font-normal text-green-700 dark:text-green-300'>
                        Wrist-friendly, portable
                      </div>
                    </TableCell>
                    <TableCell className='px-6 py-4 align-top'>
                      Enables push-ups, planche work, L-sits, and deeper range
                      of motion with reduced wrist strain.
                    </TableCell>
                  </TableRow>
                  <TableRow className='transition hover:bg-green-50/80 dark:hover:bg-green-900/10'>
                    <TableCell className='w-1/4 px-6 py-4 align-top font-semibold text-green-900 dark:text-green-100'>
                      Resistance Bands
                      <div className='mt-1 text-xs font-normal text-green-700 dark:text-green-300'>
                        Versatile, scalable
                      </div>
                    </TableCell>
                    <TableCell className='px-6 py-4 align-top'>
                      Assisted reps, mobility work, and skill progressions
                      (front levers, pull-ups, planche).
                    </TableCell>
                  </TableRow>
                  <TableRow className='transition hover:bg-green-50/80 dark:hover:bg-green-900/10'>
                    <TableCell className='w-1/4 px-6 py-4 align-top font-semibold text-green-900 dark:text-green-100'>
                      Chalk
                      <div className='mt-1 text-xs font-normal text-green-700 dark:text-green-300'>
                        Grip enhancer
                      </div>
                    </TableCell>
                    <TableCell className='px-6 py-4 align-top'>
                      Reduces sweat and improves grip for holds, pull-ups, and
                      static work.
                    </TableCell>
                  </TableRow>
                  <TableRow className='transition hover:bg-green-50/80 dark:hover:bg-green-900/10'>
                    <TableCell className='w-1/4 px-6 py-4 align-top font-semibold text-green-900 dark:text-green-100'>
                      Wrist Wraps / Bands
                      <div className='mt-1 text-xs font-normal text-green-700 dark:text-green-300'>
                        Joint support
                      </div>
                    </TableCell>
                    <TableCell className='px-6 py-4 align-top'>
                      Adds support during compression skills (handstands,
                      planche) and helps prevent overuse injuries.
                    </TableCell>
                  </TableRow>
                  <TableRow className='transition hover:bg-green-50/80 dark:hover:bg-green-900/10'>
                    <TableCell className='w-1/4 px-6 py-4 align-top font-semibold text-green-900 dark:text-green-100'>
                      Gymnastic Rings
                      <div className='mt-1 text-xs font-normal text-green-700 dark:text-green-300'>
                        Instability, challenge
                      </div>
                    </TableCell>
                    <TableCell className='px-6 py-4 align-top'>
                      Adds instability for deeper strength gains; ideal for
                      dips, levers, and skin-the-cat.
                    </TableCell>
                  </TableRow>
                  <TableRow className='transition hover:bg-green-50/80 dark:hover:bg-green-900/10'>
                    <TableCell className='w-1/4 px-6 py-4 align-top font-semibold text-green-900 dark:text-green-100'>
                      Yoga Mat / Floor Pads
                      <div className='mt-1 text-xs font-normal text-green-700 dark:text-green-300'>
                        Comfort, safety
                      </div>
                    </TableCell>
                    <TableCell className='px-6 py-4 align-top'>
                      Provides cushioning for stretching, handstands, and safer
                      landings during floor work.
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          </section>

          <Separator className='my-10' />

          {/* section: summary tips shown as badge pills */}
          <section id='recap'>
            <h2 className='mb-4 text-xl font-semibold text-green-700 dark:text-green-300'>
              Quick Recap
            </h2>
            <div className='rounded-lg bg-green-50/50 p-4 shadow-sm dark:bg-green-950/40'>
              <ul className='flex flex-wrap gap-2'>
                {[
                  'Dynamic stretch before, static after',
                  'Track progress: time or reps',
                  'Use bands for assistance',
                  'Prioritize recovery',
                  'Stretch post-workout',
                  'Choose the right gear',
                ].map((tip, i) => (
                  <li key={i}>
                    <Badge
                      variant='outline'
                      className='border-green-200 bg-white/70 px-3 py-1 text-green-800 dark:border-green-800 dark:bg-green-950/60 dark:text-green-200'
                    >
                      {tip}
                    </Badge>
                  </li>
                ))}
              </ul>
            </div>
          </section>
        </div>
      </div>
    </main>
  );
}
