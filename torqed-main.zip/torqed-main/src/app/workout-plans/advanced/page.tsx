//beginner workout plan page. pulls both global workout plan data and exercise details from firestore.
//matches exercise ids to show full details for each day. renders a nice grid of cards per workout day.

'use client';

import { useEffect, useState } from 'react';
import { collection, getDocs, doc, getDoc } from 'firebase/firestore';
import { db } from '@/firebase';
import WorkoutPlanExerciseCard from '@/app/workout-plans/components/workoutPlanExerciseCard';
import WorkoutInfo from '@/components/custom/workoutInfo';
import { Separator } from '@/components/ui/separator';
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';

// shape for each exercise from the exercise database
type Exercise = {
  id: string;
  name: string;
  level: string;
  musclesWorked: string[];
  description: string;
  difficulty: number;
  animationUrl: string;
  imageUrl?: string;
};

// shape for an exercise entry inside a workout plan day
type PlanExercise = {
  id: string;
  name?: string;
  sets?: string;
  note?: string;
};

// one day's workout structure
type DayPlan = {
  day: number;
  exercises: PlanExercise[];
};

export default function AdvancedPlanPage() {
  //holds the list of workout days/plan from db
  const [plan, setPlan] = useState<DayPlan[]>([]);

  //holds all exercises, fetched by id from db
  const [exercises, setExercises] = useState<Exercise[]>([]);

  //runs on mount: fetches all exercise info AND the beginner workout plan from firestore
  useEffect(() => {
    async function fetchData() {
      //load every exercise from firestore so we can show details
      const exSnap = await getDocs(collection(db, 'exercises'));
      const exerciseList: Exercise[] = exSnap.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Exercise[];

      //load the plan itself (array of days, each with exercise ids + extra info)
      const planSnap = await getDoc(doc(db, 'globalWorkoutPlans', 'advanced'));
      const workoutPlan = planSnap.data()?.days || [];

      setExercises(exerciseList); //so we can lookup by id
      setPlan(workoutPlan); //this is [ {day: 1, exercises: [...]}, ... ]
    }

    fetchData();
  }, []);

  return (
    <main className='mx-auto max-w-5xl px-4 py-5'>
      {/* Breadcrumb navigation */}
      <Breadcrumb className='mb-4'>
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink href='/'>Home</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href='/workout-plans'>Workout Plans</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink
              href='/workout-plans/advanced'
              className='font-semibold text-green-600'
            >
              Advanced
            </BreadcrumbLink>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>
      <h1 className='font-logo mb-6 text-4xl text-green-600'>Advanced Plan</h1>

      {/*// eslint-disable-next-line @typescript-eslint/no-unused-vars 
      // global info section for all plans  */}
      <WorkoutInfo />

      {/* for each day, show its exercises in a grid */}
      {plan.map((day) => (
        <div key={day.day} className='mb-10'>
          <Separator className='my-8' />

          <h2 className='font-logo mb-4 text-3xl text-green-500'>
            Workout Day {day.day}
          </h2>
          <div className='grid gap-4 sm:grid-cols-2 lg:grid-cols-3'>
            {day.exercises.map((ex, index) => {
              //find full exercise info by id, so we can show 3d, desc etc
              const matched = exercises.find((e) => e.id === ex.id);
              if (!matched) return null; //shouldn't happen unless db messed up

              return (
                <WorkoutPlanExerciseCard
                  //key must be unique, use combo of day+id+index just in case
                  key={`${day.day}-${ex.id}-${index}`}
                  excercise={{
                    ...matched,
                    //use plan name/sets/note if exists, else fallback
                    name: ex.name || '',
                    sets: ex.sets || '',
                    note: ex.note || '',
                  }}
                />
              );
            })}
          </div>
        </div>
      ))}
    </main>
  );
}
