'use client';

import Link from 'next/link';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { ArrowRight, Dumbbell, BarChart3, Flame } from 'lucide-react';

const plans = [
  {
    title: 'Beginner',
    description: 'Start your calisthenics journey with control and safety.',
    href: '/workout-plans/beginner',
    icon: Dumbbell,
    color: 'bg-green-100 dark:bg-green-900',
    ring: 'ring-green-300/40',
  },
  {
    title: 'Intermediate',
    description: 'Level up with challenging routines and muscle development.',
    href: '/workout-plans/intermediate',
    icon: BarChart3,
    color: 'bg-yellow-100 dark:bg-yellow-900',
    ring: 'ring-yellow-300/40',
  },
  {
    title: 'Advanced',
    description: 'Master high-skill moves and elite training techniques.',
    href: '/workout-plans/advanced',
    icon: Flame,
    color: 'bg-red-100 dark:bg-red-900',
    ring: 'ring-red-300/40',
  },
];

export default function WorkoutPlansPage() {
  return (
    <main className='mx-auto max-w-7xl px-4 py-12'>
      <div className='text-center'>
        <h1 className='font-logo mb-2 text-4xl text-green-600'>
          Workout Plans
        </h1>
        <p className='font-body text-muted-foreground mb-10 text-sm sm:text-base'>
          Choose your level and follow a day-by-day plan to reach your goals.
        </p>
      </div>

      <div className='grid gap-6 sm:grid-cols-2 lg:grid-cols-3'>
        {plans.map((plan) => (
          <Link key={plan.title} href={plan.href}>
            <Card
              className={`group relative flex h-full min-h-[250px] flex-col overflow-hidden rounded-xl border transition-transform duration-200 hover:scale-[1.02] hover:shadow-[0_0_12px_2px_#4E995C] hover:ring-2 ${plan.ring}`}
            >
              <div className={`absolute inset-0 ${plan.color} opacity-20`} />
              <CardHeader className='relative z-10 flex flex-col items-center text-center'>
                <plan.icon className='mb-2 h-8 w-8 text-green-600 dark:text-green-300' />
                <h2 className='font-logo text-2xl'>{plan.title}</h2>
              </CardHeader>
              <CardContent className='font-body text-muted-foreground relative z-10 flex flex-1 flex-col justify-between px-6 pb-6 text-center text-sm'>
                <div className='line-clamp-2'>{plan.description}</div>
                <ArrowRight className='mx-auto mt-4 transition-transform group-hover:translate-x-1' />
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </main>
  );
}
