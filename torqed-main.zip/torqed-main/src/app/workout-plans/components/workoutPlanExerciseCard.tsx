//card used on workout plan pages (beginner/intermediate/advanced)
//shows all the exercise details for a single entry in the plan
//includes plus button to add to custom workout, and 3d "view" button if available

'use client';

import { Card, CardContent, CardHeader } from '@/components/ui/card';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { useState } from 'react';
import AddToWorkoutModal from '@/components/custom/addToWorkoutModal';
import { ExerciseModalTrigger } from '@/app/exercises/components/exerciseModalTrigger';

import type { Exercise } from '@/app/exercises/page';

//props: gets a single exercise object (including sets/note from plan, not just db)
type Props = {
  excercise: Exercise & {
    sets?: string;
    note?: string;
  };
};

export default function WorkoutPlanExerciseCard({ excercise }: Props) {
  //tracks if the add-to-custom-workout modal is open
  const [modalOpen, setModalOpen] = useState(false);

  return (
    <Card className='group mb-4 transition-transform duration-200 hover:scale-105 hover:shadow-lg'>
      <CardHeader className='font-logo'>
        <div className='flex w-full items-center justify-between'>
          <h2 className='line-clamp-2 max-w-[70%] pr-2 text-xl leading-snug break-words'>
            {excercise.name}
          </h2>
          <div className='ml-auto flex items-center gap-1'>
            {/*plus button: opens modal for adding this exercise to a custom plan*/}
            <Button
              variant='ghost'
              size='sm'
              className='h-8 w-8 p-0'
              onClick={() => setModalOpen(true)}
            >
              <Plus fill='red' color='red' size={18} />
            </Button>
            {/*view 3D/animation button, if exercise has a 3d animation url*/}
            {excercise.animationUrl && (
              <ExerciseModalTrigger exercise={excercise} />
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent>
        {/*show image if exists, fallback if missing*/}
        {excercise.imageUrl ? (
          <Image
            src={excercise.imageUrl || '/fallback-image.png'}
            alt={excercise.name}
            width={320}
            height={128}
            className='mb-2 h-64 w-full rounded object-cover'
          />
        ) : null}

        {/*main exercise info: muscles, description, sets/reps, notes*/}
        <div className='font-body text-sm'>
          <p className='mb-1'>
            <span className='font-logo text-green-400'>Muscles:</span>{' '}
            {excercise.musclesWorked.join(', ')}
          </p>
          <p className='text-muted-foreground mb-2'>{excercise.description}</p>
          {excercise.sets && (
            <p className='text-sm'>
              <span className='font-logo text-blue-400'>Sets / Reps:</span>{' '}
              {excercise.sets}
            </p>
          )}
          {excercise.note && (
            <p className='mt-1 text-xs text-gray-500 italic'>
              Note: {excercise.note}
            </p>
          )}
        </div>
      </CardContent>

      {/*modal to let user add this exercise to a custom workout plan*/}
      <AddToWorkoutModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        exercise={{
          ...excercise,
          imageUrl: excercise.imageUrl || '/fallback-image.png',
        }}
      />
    </Card>
  );
}
