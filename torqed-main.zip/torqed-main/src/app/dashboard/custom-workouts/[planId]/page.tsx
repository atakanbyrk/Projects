'use client';

//displays a single custom workout plan (by planId)
//lets user edit name/description, and edit/remove individual exercises
import { useEffect, useState } from 'react';
import { doc, getDoc, updateDoc, deleteDoc } from 'firebase/firestore';
import { db } from '@/firebase';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { useParams, useRouter } from 'next/navigation';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Pencil, Trash2 } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
  AlertDialogTitle,
  AlertDialogDescription,
} from '@/components/ui/alert-dialog';
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';
import GLBViewer from '@/components/custom/GLBViewer';

//exercise format used inside each custom workout plan
type Exercise = {
  id: string;
  name: string;
  imageUrl: string;
  description: string;
  animationUrl?: string;
  setsReps: string;
};

//plan format pulled from firestore
type CustomWorkoutPlan = {
  id: string;
  name: string;
  description: string;
  exercises: Exercise[];
};

export default function CustomWorkoutDetailPage() {
  const { planId } = useParams(); //grab planId from URL
  const router = useRouter();

  const [plan, setPlan] = useState<CustomWorkoutPlan | null>(null);

  //states for editing plan name/desc
  const [editMode, setEditMode] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');

  //states for editing/deleting individual exercises
  const [editExercise, setEditExercise] = useState<Exercise | null>(null);
  const [updatedSetsReps, setUpdatedSetsReps] = useState('');
  const [deleteExerciseId, setDeleteExerciseId] = useState<string | null>(null);

  //when the page loads, fetch the workout plan from firestore using the planId in the URL
  //if found, store the plan in local state so we can display/edit it on the page
  useEffect(() => {
    const fetchPlan = async () => {
      const ref = doc(db, 'customWorkoutPlans', String(planId));
      const snapshot = await getDoc(ref);
      if (snapshot.exists()) {
        setPlan({
          id: snapshot.id,
          ...(snapshot.data() as Omit<CustomWorkoutPlan, 'id'>),
        });
      }
    };

    fetchPlan();
  }, [planId]);

  //updates the plan name and description in firestore
  //also updates local state so the UI reflects the changes without reload
  const handleUpdate = async () => {
    if (!plan) return;
    try {
      const ref = doc(db, 'customWorkoutPlans', plan.id);
      await updateDoc(ref, {
        name: newName.trim(),
        description: newDesc.trim(),
      });
      //update local state to match firestore
      setPlan((prev) =>
        prev
          ? { ...prev, name: newName.trim(), description: newDesc.trim() }
          : null,
      );
      toast.success('Workout plan updated!');
      setEditMode(false);
    } catch {
      toast.error('Failed to update');
    }
  };

  //delete the whole plan and go back to dashboard
  const handleDelete = async () => {
    if (!plan) return;
    try {
      await deleteDoc(doc(db, 'customWorkoutPlans', plan.id));
      toast.success('Workout plan deleted');
      router.push('/dashboard');
    } catch {
      toast.error('Failed to delete');
    }
  };

  //updates the sets/reps value for a single exercise in the workout plan
  //replaces the matching exercise locally and in firestore using map()
  const handleExerciseUpdate = async (
    exerciseId: string,
    newSetsReps: string,
  ) => {
    if (!plan) return;

    const updatedExercises = plan.exercises.map((ex) =>
      ex.id === exerciseId ? { ...ex, setsReps: newSetsReps } : ex,
    );

    try {
      const ref = doc(db, 'customWorkoutPlans', plan.id);
      await updateDoc(ref, { exercises: updatedExercises });
      //update local state so user sees changes instantly
      setPlan({ ...plan, exercises: updatedExercises });
      toast.success('Exercise updated!');
    } catch {
      toast.error('Failed to update exercise');
    }
  };

  //removes an exercise from the workout plan both in firestore and locally
  //filters out the exercise by id, updates the db, and refreshes local state
  const handleExerciseDelete = async (exerciseId: string) => {
    if (!plan) return;

    //create new array without the exercise that matches the given id
    //basically removes it by filtering it out
    const updatedExercises = plan.exercises.filter(
      (ex) => ex.id !== exerciseId,
    );

    try {
      const ref = doc(db, 'customWorkoutPlans', plan.id);
      await updateDoc(ref, { exercises: updatedExercises });
      //update local state so it disappears right away in the UI
      setPlan({ ...plan, exercises: updatedExercises });
      toast.success('Exercise removed!');
    } catch {
      toast.error('Failed to remove exercise');
    }
  };

  if (!plan) return <p className='p-4'>Loading workout plan...</p>;

  return (
    <section className='mx-auto max-w-5xl p-6'>
      {plan && (
        <div className='mb-6'>
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink href='/dashboard'>Dashboard</BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbLink href='/dashboard/custom-workouts'>
                  Custom Workouts
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <span className='font-semibold text-green-600'>{plan.name}</span>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
        </div>
      )}

      <div className='mb-2 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between'>
        <div>
          <h2 className='text-3xl font-logo tracking-tight'>
            {plan.name}
          </h2>
          <p className='font-body text-muted-foreground mt-1'>{plan.description}</p>
        </div>
        <div className='flex gap-2'>
          <Button
            size='sm'
            variant='outline'
            onClick={() => {
              setEditMode(true);
              setNewName(plan.name);
              setNewDesc(plan.description);
            }}
          >
            <Pencil size={16} className='mr-1' /> Edit
          </Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button size='sm' variant='destructive'>
                <Trash2 size={16} className='mr-1' /> Delete
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete this workout plan?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action is permanent and will remove the workout plan and
                  its contents.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete}>
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      <Dialog open={editMode} onOpenChange={setEditMode}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Workout Plan</DialogTitle>
          </DialogHeader>
          <input
            type='text'
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder='Plan name'
            className='focus:ring-primary mb-2 w-full rounded border p-2 focus:ring-2 focus:outline-none'
          />
          <textarea
            value={newDesc}
            onChange={(e) => setNewDesc(e.target.value)}
            placeholder='Plan description'
            className='focus:ring-primary mb-2 w-full rounded border p-2 focus:ring-2 focus:outline-none'
            rows={3}
          />
          <DialogFooter>
            <Button
              onClick={handleUpdate}
              disabled={!newName.trim() || !newDesc.trim()}
            >
              Save
            </Button>
            <Button variant='ghost' onClick={() => setEditMode(false)}>
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {plan.exercises.length === 0 ? (
        <div className='mt-16 flex flex-col items-center justify-center'>
          <p className='font-logo text-red-600 text-lg'>
            No exercises added to this plan yet.
          </p>
        </div>
      ) : (
        <div className='mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3'>
          {plan.exercises.map((exercise) => (
            <Card
              key={exercise.id}
              className='border-primary/20 transition-shadow hover:shadow-lg'
            >
              <CardHeader className='flex flex-row items-center justify-between pb-2'>
                <div>
                  <h3 className='text-lg font-logo text-green-600'>{exercise.name}</h3>
                </div>
                <div className='flex gap-1'>
                  <Dialog
                    open={editExercise?.id === exercise.id}
                    onOpenChange={(open) => {
                      if (!open) setEditExercise(null);
                    }}
                  >
                    <DialogTrigger asChild>
                      <Button
                        size='icon'
                        variant='outline'
                        onClick={() => {
                          setEditExercise(exercise);
                          setUpdatedSetsReps(exercise.setsReps);
                        }}
                        aria-label='Edit sets/reps'
                      >
                        <Pencil size={15} />
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Edit Sets/Reps</DialogTitle>
                      </DialogHeader>
                      <input
                        type='text'
                        value={updatedSetsReps}
                        onChange={(e) => setUpdatedSetsReps(e.target.value)}
                        placeholder='e.g. 3x5, max hold'
                        className='focus:ring-primary mt-4 w-full rounded border p-2 focus:ring-2 focus:outline-none'
                      />
                      <DialogFooter>
                        <Button
                          onClick={() => {
                            if (editExercise && updatedSetsReps.trim()) {
                              handleExerciseUpdate(
                                editExercise.id,
                                updatedSetsReps.trim(),
                              );
                              setEditExercise(null);
                            }
                          }}
                          disabled={!updatedSetsReps.trim()}
                        >
                          Save
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        size='icon'
                        variant='destructive'
                        onClick={() => setDeleteExerciseId(exercise.id)}
                        aria-label='Delete exercise'
                      >
                        <Trash2 size={15} />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>
                          Delete this exercise?
                        </AlertDialogTitle>
                        <AlertDialogDescription>
                          This will remove the exercise from your workout plan.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => {
                            if (deleteExerciseId)
                              handleExerciseDelete(deleteExerciseId);
                            setDeleteExerciseId(null);
                          }}
                        >
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardHeader>
              <CardContent>
                {exercise.animationUrl ? (
                  <div className='bg-muted mb-3 flex h-56 w-full items-center justify-center overflow-hidden rounded-lg'>
                    <GLBViewer url={exercise.animationUrl} />
                  </div>
                ) : (
                  <div className='bg-red-600 text-muted-foreground mb-3 flex h-56 w-full items-center justify-center rounded-lg text-4xl'>
                    edge case
                  </div>
                )}
                <p className='font-body mb-2 min-h-[48px] text-sm'>
                  {exercise.description}
                </p>
                <div className='flex items-center gap-2'>
                  <span className='font-logo rounded bg-green-100 px-2 py-1 text-xs text-green-700 dark:bg-green-900 dark:text-green-300'>
                    Sets/Reps: {exercise.setsReps}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </section>
  );
}
