'use client';

//displays a list of all custom workout plans created by the logged-in user
//each plan links to its own detail page with exercises

import { useEffect, useState } from 'react';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { useUser } from '@/lib/hooks/useUser';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import Link from 'next/link';
import { format } from 'date-fns';
import { db } from '@/firebase';
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';

//shape of each custom workout plan pulled from firestore
type CustomWorkoutPlan = {
  id: string;
  name: string;
  description: string;
  createdAt?: { seconds: number; nanoseconds: number };
};

export default function CustomWorkoutListPage() {
  const { user } = useUser();
  const [plans, setPlans] = useState<CustomWorkoutPlan[]>([]);

  //fetches all plans made by the current user
  //runs once user is available (from custom useUser hook)
  //gets from customWorkoutPlans where userId == current user
  useEffect(() => {
    if (!user?.uid) return;

    const fetchPlans = async () => {
      const q = query(
        collection(db, 'customWorkoutPlans'),
        where('userId', '==', user.uid),
      );
      const snapshot = await getDocs(q);
      const plansData = snapshot.docs.map((doc) => ({
        id: doc.id, //doc.id is the auto-generated Firestore ID (not included in doc.data) - we manually attach it for linking/editing
        ...(doc.data() as Omit<CustomWorkoutPlan, 'id'>), //spread the rest of the plan fields (name, description, createdAt)
      }));

      setPlans(plansData);
    };

    fetchPlans();
  }, [user]);

  if (!user)
    return <p className='p-4'>Please log in to see your custom workouts.</p>;

  return (
    <section className='p-6'>
      {/* Breadcrumb + New Workout button */}
      <div className='mb-6 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center'>
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href='/dashboard'>Dashboard</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink
                href='/dashboard/custom-workouts'
                className='font-semibold text-green-600'
              >
                Custom Workouts
              </BreadcrumbLink>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        {/* New Workout button, right aligned on desktop */}
        <Link href='/exercises'>
          <button
            className='font-logo inline-flex items-center gap-2 rounded-lg bg-green-600 px-4 py-2 text-base text-white shadow-md transition hover:bg-green-700'
            title='Create new custom workout plan'
          >
            <svg
              width='20'
              height='20'
              fill='none'
              stroke='currentColor'
              strokeWidth='2'
              viewBox='0 0 24 24'
            >
              <path
                d='M12 4v16m8-8H4'
                strokeLinecap='round'
                strokeLinejoin='round'
              />
            </svg>
            New Workout
          </button>
        </Link>
      </div>

      <h2 className='font-logo mb-4 text-2xl text-green-600'>
        Your Custom Workout Plans
      </h2>

      <div className='grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3'>
        {plans.map((plan) => (
          <Link href={`/dashboard/custom-workouts/${plan.id}`} key={plan.id}>
            <Card className='group cursor-pointer border-green-200 transition-all hover:scale-[1.02] hover:shadow-lg dark:border-green-900'>
              <CardHeader className='pb-2'>
                <h3 className='font-logo text-xl transition group-hover:text-green-600'>
                  {plan.name}
                </h3>
              </CardHeader>
              <CardContent>
                <p className='text-muted-foreground font-body mb-2 line-clamp-2'>
                  {plan.description}
                </p>
                {plan.createdAt && (
                  <p className='font-mono text-xs text-gray-500'>
                    Created on{' '}
                    {format(new Date(plan.createdAt.seconds * 1000), 'PPP')}
                  </p>
                )}
              </CardContent>
            </Card>
          </Link>
        ))}
        {plans.length === 0 && (
          <p className='text-muted-foreground font-body col-span-full py-10 text-center text-lg'>
            No custom workout plans yet. Start by creating one!
          </p>
        )}
      </div>
    </section>
  );
}
