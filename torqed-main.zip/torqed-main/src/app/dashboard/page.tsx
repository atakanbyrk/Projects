//dashboard page: shows welcome message, recent workout plans, and editable profile info for the logged-in user
'use client';

//firebase + routing stuff
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { auth, db } from '@/firebase';
import { onAuthStateChanged, signOut, User } from 'firebase/auth';
import {
  collection,
  getDocs,
  query,
  updateDoc,
  where,
  doc,
  getDoc,
  deleteDoc,
} from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';

//ui components
import { Card } from '@/components/ui/card';
import Link from 'next/link';
import { format } from 'date-fns';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { Pencil, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
  AlertDialogTitle,
  AlertDialogDescription,
} from '@/components/ui/alert-dialog';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';

//main dashboard component. runs auth check, fetches workout plans + user info, and renders them
export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [authChecked, setAuthChecked] = useState(false);

  //represents extra profile fields from firestore /users
  interface UserData {
    name?: string;
    surname?: string;
    photoURL?: string;
    weight?: string;
    height?: string;
  }

  //handles uploading user profile pictures to firebase storage
  //1. uploads the selected image to /user_uploads/uid/avatar
  //2. gets the public download URL from firebase
  //3. updates local form state with the URL so it shows in the UI
  //this doesn't auto-save to firestore, just updates formState. we save it later with handleProfileSave
  const handleImageUpload = async (file: File) => {
    if (!user) return;
    try {
      const storage = getStorage();
      const storageRef = ref(storage, `user_uploads/${user.uid}/avatar`);
      await uploadBytes(storageRef, file);
      const downloadURL = await getDownloadURL(storageRef);
      setFormState((s) => ({ ...s, photoURL: downloadURL }));
      toast.success('Image uploaded');
    } catch (err) {
      toast.error('Failed to upload image');
      console.error(err);
    }
  };

  const [userData, setUserData] = useState<UserData | null>(null);

  //type structure for workouts stored in firestore
  type CustomWorkoutPlan = {
    id: string;
    name: string;
    description: string;
    createdAt?: { seconds: number; nanoseconds: number };
  };

  //state for workouts and edit modals
  const [plans, setPlans] = useState<CustomWorkoutPlan[]>([]);
  const [editingPlanId, setEditingPlanId] = useState<string | null>(null);
  const [editedName, setEditedName] = useState('');
  const [editedDesc, setEditedDesc] = useState('');

  //state for profile edit dialog + values
  const [profileDialogOpen, setProfileDialogOpen] = useState(false);
  const [formState, setFormState] = useState({
    name: '',
    surname: '',
    photoURL: '',
    weight: '',
    height: '',
  });

  //runs on page load: checks if user is logged in and pulls their profile info from firestore
  //if user is not logged in, redirects to login page
  //if user doc exists → load profile data (name, image, etc) into local state
  //also sets authChecked so we don’t show stuff too early while waiting for firebase
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      setAuthChecked(true);
      if (!u) return router.push('/login');

      const ref = doc(db, 'users', u.uid);
      const snap = await getDoc(ref);
      if (snap.exists()) {
        setUserData(snap.data());
        setFormState({
          name: snap.data().name || '',
          surname: snap.data().surname || '',
          photoURL: snap.data().photoURL || '',
          weight: snap.data().weight || '',
          height: snap.data().height || '',
        });
      }
    });
    return () => unsub();
  }, [router]);

  //pulls workout plans created by the logged-in user from firestore
  //filters with where(userId == currentUser.uid) to get only their plans
  //once fetched, sorts by createdAt date (newest first) and stores in state
  //only runs after user state is set, otherwise skipped
  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'customWorkoutPlans'),
      where('userId', '==', user.uid),
    );
    //fetches documents using the query q.
    //maps over the documents in the snapshot to create an array of workout plans.
    //each plan includes the document id and the rest of the data cast to the CustomWorkoutPlan type excluding the id field.
    getDocs(q).then((snapshot) => {
      const fetchedPlans = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...(doc.data() as Omit<CustomWorkoutPlan, 'id'>),
      }));

      //sorts plans by created timestamp, fallback 0 if missing
      setPlans(
        fetchedPlans.sort((a, b) => {
          if (!a.createdAt || !b.createdAt) return 0;
          return b.createdAt.seconds - a.createdAt.seconds;
        }),
      );
    });
  }, [user]);

  //deletes a workout plan from firestore and removes it from local state
  //asks for confirm before deleting. if user confirms, deletes doc by ID
  //after successful delete, updates state to remove that plan from UI
  //shows toast either way (success or error)
  const handleDelete = async (planId: string) => {
    const confirm = window.confirm(
      'Are you sure you want to delete this plan?',
    );
    if (!confirm) return;

    try {
      await deleteDoc(doc(db, 'customWorkoutPlans', planId));
      setPlans((prev) => prev.filter((plan) => plan.id !== planId));
      toast.success('Workout plan deleted');
    } catch (err: unknown) {
      if (err instanceof Error) toast.error(err.message);
      else toast.error('Failed to delete plan');
    }
  };

  //updates workout plan name + description in firestore
  //checks that inputs aren't empty first (basic validation)
  //if successful → updates the matching plan in state so UI reflects changes instantly
  //then closes the dialog and shows toast
  const handlePlanUpdate = async (planId: string) => {
    if (!editedName.trim() || !editedDesc.trim()) {
      toast.error('Name and description cannot be empty');
      return;
    }

    try {
      const ref = doc(db, 'customWorkoutPlans', planId);
      await updateDoc(ref, {
        name: editedName.trim(),
        description: editedDesc.trim(),
      });
      setPlans((prev) =>
        prev.map((plan) =>
          plan.id === planId
            ? {
                ...plan,
                name: editedName.trim(),
                description: editedDesc.trim(),
              }
            : plan,
        ),
      );
      toast.success('Workout plan updated');
      setEditingPlanId(null);
    } catch {
      toast.error('Failed to update plan');
    }
  };

  //saves edited profile info to firestore (name, surname, image, weight, height)
  //runs when user hits “save” on the profile edit modal
  //writes directly to users collection (doc id = user.uid)
  //after saving → closes the modal + shows toast
  const handleProfileSave = async () => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), { ...formState });
      toast.success('Profile updated');
      setProfileDialogOpen(false);
    } catch {
      toast.error('Failed to update profile');
    }
  };

  //render loading state if still checking auth
  if (!authChecked) return <div>Loading...</div>;

  return (
    <main className='mx-auto max-w-5xl space-y-10 p-6'>
      {/* Section 1: Welcome */}
      <section className='bg-card flex flex-col gap-4 rounded-xl border p-6 shadow-sm sm:flex-row sm:items-center sm:justify-between'>
        <div>
          <h1 className='font-logo flex items-center gap-2 text-3xl font-bold text-green-600'>
            <Avatar className='h-10 w-10 border shadow'>
              <AvatarImage src={userData?.photoURL || formState.photoURL} />
              <AvatarFallback>
                {userData?.name?.[0]?.toUpperCase() ||
                  user?.email?.[0]?.toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <span>
              Welcome,{' '}
              <span className='text-emerald-800'>
                {userData?.name
                  ? `${userData.name}${userData.surname ? ` ${userData.surname}` : ''}`
                  : user?.email}
              </span>
            </span>
          </h1>
          <p className='text-muted-foreground mt-1 text-sm'>
            You&apos;re logged in as{' '}
            <span className='font-medium'>{user?.email}</span>
          </p>
        </div>
        <Button
          variant='outline'
          className='self-start sm:self-auto'
          onClick={() => signOut(auth)}
        >
          Log out
        </Button>
      </section>

      <Separator className='my-6' />

      {/* Section 2: Custom Workout Plans */}
      <section>
        <div className='mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between'>
          <h2 className='flex items-center gap-2 text-2xl font-semibold text-emerald-800'>
            Your Custom Workout Plans
            <span className='ml-2 rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-medium text-emerald-700'>
              {plans.length}
            </span>
          </h2>
          <div className='flex gap-3'>
            <Link
              href='/dashboard/custom-workouts'
              className='text-sm text-blue-600 underline-offset-2 hover:underline'
            >
              See all →
            </Link>
            <Link
              href='/exercises'
              className='rounded bg-blue-500 px-3 py-1 text-sm font-medium text-white shadow transition hover:bg-blue-600'
            >
              + Create Plan
            </Link>
          </div>
        </div>

        {plans.length === 0 ? (
          <Card className='text-muted-foreground p-6 text-center'>
            You haven&apos;t created any plans yet.
            <div className='mt-4'>
              <Link
                href='/exercises'
                className='inline-block rounded bg-emerald-600 px-4 py-2 font-semibold text-white shadow transition hover:bg-emerald-700'
              >
                Create your first plan
              </Link>
            </div>
          </Card>
        ) : (
          <div className='grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3'>
            {plans.slice(0, 4).map((plan) => (
              <Card
                key={plan.id}
                className='group relative transition-all hover:scale-[1.01] hover:shadow-lg'
              >
                <div className='absolute top-2 right-2 z-10 flex gap-2 opacity-0 transition group-hover:opacity-100'>
                  <Button
                    size='icon'
                    className='h-7 w-7 rounded-full bg-white/80 p-0 hover:bg-white'
                    onClick={() => {
                      setEditingPlanId(plan.id);
                      setEditedName(plan.name);
                      setEditedDesc(plan.description);
                    }}
                    title='Edit Plan'
                    aria-label='Edit Plan'
                  >
                    <Pencil size={14} />
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        size='icon'
                        className='h-7 w-7 rounded-full bg-red-500 p-0 text-white hover:bg-red-600'
                        title='Delete Plan'
                        aria-label='Delete Plan'
                      >
                        <Trash2 size={14} />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>
                          Delete this workout plan?
                        </AlertDialogTitle>
                        <AlertDialogDescription>
                          This will permanently remove the plan and its
                          exercises. Are you sure?
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => handleDelete(plan.id)}
                        >
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
                <Link
                  href={`/dashboard/custom-workouts/${plan.id}`}
                  className='block h-full rounded p-4 transition focus:ring-2 focus:ring-emerald-400 focus:outline-none'
                  tabIndex={0}
                >
                  <h3 className='mb-1 truncate text-lg font-semibold transition group-hover:text-emerald-700'>
                    {plan.name}
                  </h3>
                  <p className='text-muted-foreground mb-2 line-clamp-2 text-sm'>
                    {plan.description}
                  </p>
                  {plan.createdAt && (
                    <p className='text-xs text-gray-500'>
                      Created on{' '}
                      {format(new Date(plan.createdAt.seconds * 1000), 'PPP')}
                    </p>
                  )}
                </Link>
                <Dialog
                  open={editingPlanId === plan.id}
                  onOpenChange={(open) => {
                    if (!open) setEditingPlanId(null);
                  }}
                >
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Edit Plan</DialogTitle>
                    </DialogHeader>
                    <input
                      type='text'
                      value={editedName}
                      onChange={(e) => setEditedName(e.target.value)}
                      placeholder='Plan name'
                      className='mb-2 w-full rounded border p-2'
                      maxLength={40}
                      autoFocus
                    />
                    <textarea
                      value={editedDesc}
                      onChange={(e) => setEditedDesc(e.target.value)}
                      placeholder='Plan description'
                      className='mb-2 w-full rounded border p-2'
                      maxLength={120}
                      rows={3}
                    />
                    <DialogFooter>
                      <Button
                        onClick={() => handlePlanUpdate(plan.id)}
                        disabled={!editedName.trim() || !editedDesc.trim()}
                      >
                        Save
                      </Button>
                      <Button
                        variant='ghost'
                        onClick={() => setEditingPlanId(null)}
                      >
                        Cancel
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </Card>
            ))}
          </div>
        )}
      </section>

      <Separator className='my-6' />

      {/* Section 3: Profile Info */}
      <section>
        <h2 className='mb-4 text-xl font-bold text-emerald-800'>My Profile</h2>
        <div className='flex flex-col items-center gap-8 sm:flex-row sm:items-start'>
          <div className='relative'>
            <Avatar className='h-24 w-24 border shadow-md'>
              <AvatarImage src={formState.photoURL} />
              <AvatarFallback>
                {formState.name?.[0]?.toUpperCase() ||
                  user?.email?.[0]?.toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <Button
              size='icon'
              variant='ghost'
              className='absolute right-1 bottom-1 h-8 w-8 rounded-full bg-emerald-900 p-0 text-white shadow hover:bg-emerald-700 dark:hover:bg-emerald-500'
              title='Change Photo'
              aria-label='Change Photo'
              onClick={() => {
                const input = document.getElementById('profile-photo-input');
                if (input) input.click();
              }}
            >
              <Pencil size={16} />
            </Button>
            <input
              id='profile-photo-input'
              type='file'
              accept='image/*'
              style={{ display: 'none' }}
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  if (!file.type.startsWith('image/')) {
                    toast.error('Please upload an image file');
                    return;
                  }
                  if (file.size > 2 * 1024 * 1024) {
                    toast.error('Image size must be under 2MB');
                    return;
                  }
                  handleImageUpload(file);
                }
              }}
            />
          </div>
          <div className='text-muted-foreground w-full max-w-xs space-y-1 text-sm'>
            <p>
              <strong>Name:</strong> {formState.name || '-'} {formState.surname}
            </p>
            <p>
              <strong>Email:</strong> {user?.email}
            </p>
            <p>
              <strong>Weight:</strong> {formState.weight || '-'} kg
            </p>
            <p>
              <strong>Height:</strong> {formState.height || '-'} cm
            </p>
            <Button
              variant='default'
              className='mt-3'
              onClick={() => setProfileDialogOpen(true)}
            >
              Edit Profile
            </Button>
          </div>
        </div>

        <Dialog open={profileDialogOpen} onOpenChange={setProfileDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Profile</DialogTitle>
            </DialogHeader>
            <div className='flex flex-col gap-2'>
              <div className='flex gap-2'>
                <input
                  type='text'
                  placeholder='Name'
                  value={formState.name}
                  onChange={(e) =>
                    setFormState((s) => ({ ...s, name: e.target.value }))
                  }
                  className='flex-1 rounded border p-2'
                  maxLength={30}
                  autoFocus
                />
                <input
                  type='text'
                  placeholder='Surname'
                  value={formState.surname}
                  onChange={(e) =>
                    setFormState((s) => ({ ...s, surname: e.target.value }))
                  }
                  className='flex-1 rounded border p-2'
                  maxLength={30}
                />
              </div>
              <div className='flex gap-2'>
                <input
                  type='number'
                  placeholder='Weight (kg)'
                  value={formState.weight}
                  onChange={(e) =>
                    setFormState((s) => ({ ...s, weight: e.target.value }))
                  }
                  className='flex-1 rounded border p-2'
                  min={0}
                  max={500}
                />
                <input
                  type='number'
                  placeholder='Height (cm)'
                  value={formState.height}
                  onChange={(e) =>
                    setFormState((s) => ({ ...s, height: e.target.value }))
                  }
                  className='flex-1 rounded border p-2'
                  min={0}
                  max={300}
                />
              </div>
              <div className='flex items-center gap-2'>
                <Avatar className='h-10 w-10 border'>
                  <AvatarImage src={formState.photoURL} />
                  <AvatarFallback>
                    {formState.name?.[0]?.toUpperCase() ||
                      user?.email?.[0]?.toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <label className='text-xs text-gray-600'>
                  Change profile photo:
                  <input
                    type='file'
                    accept='image/*'
                    className='ml-2'
                    style={{ display: 'inline-block' }}
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        if (!file.type.startsWith('image/')) {
                          toast.error('Please upload an image file');
                          return;
                        }
                        if (file.size > 2 * 1024 * 1024) {
                          toast.error('Image size must be under 2MB');
                          return;
                        }
                        handleImageUpload(file);
                      }
                    }}
                  />
                </label>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleProfileSave}>Save</Button>
              <Button
                variant='ghost'
                onClick={() => setProfileDialogOpen(false)}
              >
                Cancel
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </section>
    </main>
  );
}
