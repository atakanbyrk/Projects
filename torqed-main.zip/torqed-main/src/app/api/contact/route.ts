import { NextRequest, NextResponse } from 'next/server'; // next.js api types
import { Resend } from 'resend'; // resend email service

const resend = new Resend(process.env.RESEND_API_KEY); // initialize resend with api key

// handle post requests to the contact api route
export async function POST(req: NextRequest) {
  // get name, email, and message from the request body
  const { name, email, message } = await req.json();
  try {
    // send an email using resend
    await resend.emails.send({
      from: 'Torqed Contact <contact@torqed.net>', // sender
      to: 'ekerdiker18@gmail.com', // recipient
      subject: 'contact form submission', // subject
      text: `from: ${name} <${email}>\n\n${message}`, // body
    });
    // respond with success
    return NextResponse.json({ success: true });
  } catch (error) {
    // log error and respond with failure
    console.error(error);
    return NextResponse.json(
      { error: 'failed to send message.' },
      { status: 500 },
    );
  }
}
