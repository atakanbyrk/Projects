'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import Head from 'next/head';

export default function PrivacyPolicyPage() {
  return (
    <>
      <Head>
        <title>Privacy Policy | TorQed</title>
        <meta name="description" content="Read the privacy policy for TorQed, your modern calisthenics guide and fitness web app." />
      </Head>
      <main className='mx-auto max-w-3xl px-4 py-12'>
        <Card>
          <CardHeader>
            <CardTitle className='font-logo text-2xl text-green-700'>
              Privacy Policy
            </CardTitle>
          </CardHeader>
          <CardContent className='font-body text-muted-foreground space-y-6 text-base'>
            <section>
              <h2 className='mb-2 text-lg font-semibold'>Who we are</h2>
              <p>
                TorQed is a fitness web application owned and operated by
                <span className='text-green-700'> torqed.net</span>, dedicated to providing modern calisthenics training tools.
                <br />
                Our site address is: <a href='https://torqed.net' className='text-green-700 underline'>https://torqed.net</a>
              </p>
            </section>
            <section>
              <h2 className='mb-2 text-lg font-semibold'>What personal data we collect & why</h2>
              <ul className='list-inside list-disc space-y-2'>
                <li>
                  <span className='font-medium text-green-700'>Account Info:</span> We collect your name, email, and (optionally) a profile photo, height, and weight when you register. This is used only to personalise your account and for your own training stats.
                </li>
                <li>
                  <span className='font-medium text-green-700'>Usage Data:</span> We may collect data on how you use the site (like which workouts you view or create) to improve features and user experience. No sensitive info is ever shared or sold.
                </li>
                <li>
                  <span className='font-medium text-green-700'>Google Login:</span> If you sign in with Google, we only access your basic account info for authentication.
                </li>
              </ul>
            </section>
            <section>
              <h2 className='mb-2 text-lg font-semibold'>Who we share your data with</h2>
              <p>
                We do <span className='font-bold text-green-700'>not</span> sell or share your personal data with third parties. Your workout data is private and only accessible by you.
              </p>
            </section>
            <section>
              <h2 className='mb-2 text-lg font-semibold'>How long we retain your data</h2>
              <p>
                Your account data is stored for as long as you use our service. If you delete your account, your information and workouts are permanently erased from our database.
              </p>
            </section>
            <section>
              <h2 className='mb-2 text-lg font-semibold'>Your rights</h2>
              <ul className='list-inside list-disc space-y-2'>
                <li>
                  You can update or delete your account information any time from your profile page.
                </li>
                <li>
                  If you want all your data erased, email us at{' '}
                  <a href='mailto:contact@torqed.net' className='text-green-700 underline'>contact@torqed.net</a> and we’ll delete it for you.
                </li>
              </ul>
            </section>
            <section>
              <h2 className='mb-2 text-lg font-semibold'>Contact</h2>
              <p>
                For privacy concerns or data requests, contact us at{' '}
                <a href='mailto:contact@torqed.net' className='text-green-700 underline'>contact@torqed.net</a>.
              </p>
            </section>
            <section>
              <h2 className='mb-2 text-lg font-semibold'>Policy Updates</h2>
              <p>
                We may update this privacy policy. Changes will be posted on this page. Continued use of TorQed means you accept the new policy.
              </p>
            </section>
          </CardContent>
        </Card>
      </main>
    </>
  );
}
