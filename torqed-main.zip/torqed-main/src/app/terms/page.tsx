'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import Link from 'next/link';

export default function TermsOfServicePage() {
  return (
    <main className='mx-auto max-w-3xl px-4 py-12'>
      <Card>
        <CardHeader>
          <CardTitle className='font-logo text-2xl text-green-700'>
            Terms of Service
          </CardTitle>
        </CardHeader>
        <CardContent className='font-body text-muted-foreground space-y-7 text-base'>
          <div>
            <h2 className='mb-2 text-lg font-semibold'>Acceptance of Terms</h2>
            <p>
              By using TorQed (
              <Link href='/' className='text-green-700 underline'>
                torqed.net
              </Link>
              ), you agree to these Terms of Service and to follow all
              applicable laws and regulations. If you don&apos;t agree, please
              do not use our site.
            </p>
          </div>
          <div>
            <h2 className='mb-2 text-lg font-semibold'>Who Can Use TorQed</h2>
            <p>
              You must be at least 16 years old to register or use TorQed. If
              you are under 16, you need a parent or guardian’s permission.
            </p>
          </div>
          <div>
            <h2 className='mb-2 text-lg font-semibold'>User Accounts</h2>
            <ul className='list-inside list-disc space-y-2'>
              <li>
                You are responsible for keeping your account secure. Don’t share
                your password with others.
              </li>
              <li>
                If you think your account is compromised, email us at{' '}
                <a
                  href='mailto:contact@torqed.net'
                  className='text-green-700 underline'
                >
                  contact@torqed.net
                </a>
                .
              </li>
              <li>
                You may not impersonate others or create accounts using false
                info.
              </li>
            </ul>
          </div>
          <div>
            <h2 className='mb-2 text-lg font-semibold'>
              Content & Use of Service
            </h2>
            <ul className='list-inside list-disc space-y-2'>
              <li>
                All workouts, content, and features on TorQed are for
                educational and informational purposes only. Use at your own
                risk.
              </li>
              <li>
                Do not use TorQed to post or share illegal, abusive, or harmful
                content.
              </li>
              <li>You may not reverse-engineer, resell, or misuse TorQed.</li>
            </ul>
          </div>
          <div>
            <h2 className='mb-2 text-lg font-semibold'>Health Disclaimer</h2>
            <p>
              TorQed is not a substitute for professional medical advice. Always
              consult with your doctor before starting any new exercise program.
              Stop using our site and seek medical attention if you experience
              pain, dizziness, or other health issues.
            </p>
          </div>
          <div>
            <h2 className='mb-2 text-lg font-semibold'>Account Termination</h2>
            <p>
              We reserve the right to suspend or delete your account if you
              violate these terms or misuse TorQed.
            </p>
          </div>
          <div>
            <h2 className='mb-2 text-lg font-semibold'>Privacy</h2>
            <p>
              See our{' '}
              <Link href='/privacy-policy' className='text-green-700 underline'>
                Privacy Policy
              </Link>{' '}
              for information on how we handle your data.
            </p>
          </div>
          <div>
            <h2 className='mb-2 text-lg font-semibold'>
              Changes to These Terms
            </h2>
            <p>
              We may update these Terms of Service. If we make big changes,
              we’ll post a notice on this page. Your continued use of TorQed
              means you accept the updated terms.
            </p>
          </div>
          <div>
            <h2 className='mb-2 text-lg font-semibold'>Contact</h2>
            <p>
              For questions or concerns, contact us at{' '}
              <a
                href='mailto:contact@torqed.net'
                className='text-green-700 underline'
              >
                contact@torqed.net
              </a>
              .
            </p>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
