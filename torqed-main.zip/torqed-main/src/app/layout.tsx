import './globals.css';
import type { Metadata } from 'next';
import Navbar from '@/components/custom/navbar';
import Footer from '@/components/custom/footer';
import ThemeProvider from '@/provider/theme-provider';
import localFont from 'next/font/local';
import { Toaster } from 'sonner'; 

const qualyBold = localFont({
  src: '../fonts/qualybold.ttf',
  variable: '--font-qualy-bold',
  display: 'swap',
});

const gillSansMT = localFont({
  src: '../fonts/gillsansmt.ttf',
  variable: '--font-gill-sans-mt',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'TorQed',
  description: 'Your complete calisthenics workout companion.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang='en'
      className={`${qualyBold.variable} ${gillSansMT.variable}`}
      suppressHydrationWarning
    >
      <body>
        <ThemeProvider
          attribute='class'
          defaultTheme='system'
          enableSystem
          disableTransitionOnChange
        >
          <Navbar />
          {children}
          <Footer />
          <Toaster position='bottom-right' richColors /> 
        </ThemeProvider>
      </body>
    </html>
  );
}
