'use client';

import { useState } from 'react';
import { Mail } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';

export default function ContactPage() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      if (res.ok) setSubmitted(true);
      else alert('There was an error sending your message.');
    } catch {
      alert('There was an error sending your message.');
    }
    setLoading(false);
  };

  return (
    <div className='flex min-h-[80vh] items-center justify-center px-4'>
      <div className='bg-secondary w-full max-w-md rounded-2xl border p-8 shadow-xl'>
        <div className='mb-8 flex flex-col items-center'>
          <span className='mb-3 rounded-full bg-green-100 p-3 dark:bg-green-900/30'>
            <Mail size={36} className='text-green-600 dark:text-green-400' />
          </span>
          <h1 className='font-logo mb-2 text-3xl font-bold text-green-700 dark:text-green-400'>
            Contact Us
          </h1>
          <p className='font-body text-center text-base text-gray-500 dark:text-gray-300'>
            Have a question? Reach out and we&apos;ll get back to you soon.
          </p>
        </div>
        {submitted ? (
          <div className='font-body py-16 text-center text-lg font-semibold text-green-700 dark:text-green-400'>
            Thank you for contacting us!
            <br />
            We&apos;ll get back to you soon.
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            className='font-logo flex flex-col gap-5'
          >
            <div>
              <label
                htmlFor='name'
                className='mb-1 block text-sm text-green-700 dark:text-green-400'
              >
                Name
              </label>
              <Input
                id='name'
                name='name'
                placeholder='Your Name'
                value={form.name}
                onChange={handleChange}
                required
                autoFocus
                className='font-body'
              />
            </div>
            <div>
              <label
                htmlFor='email'
                className='mb-1 block text-sm text-green-700 dark:text-green-400'
              >
                Email
              </label>
              <Input
                id='email'
                name='email'
                type='email'
                placeholder='Your Email'
                value={form.email}
                onChange={handleChange}
                required
                className='font-body'
              />
            </div>
            <div>
              <label
                htmlFor='message'
                className='mb-1 block text-sm text-green-700 dark:text-green-400'
              >
                Message
              </label>
              <Textarea
                id='message'
                name='message'
                placeholder='Your Message'
                value={form.message}
                onChange={handleChange}
                rows={5}
                required
                className='font-body'
              />
            </div>
            <Button
              type='submit'
              className='font-logo w-full rounded-lg bg-green-600 py-2 text-lg text-white shadow transition-all hover:bg-green-700'
              disabled={loading}
            >
              {loading ? (
                <span className='flex items-center justify-center gap-2'>
                  <svg
                    className='h-5 w-5 animate-spin text-white'
                    viewBox='0 0 24 24'
                  >
                    <circle
                      className='opacity-25'
                      cx='12'
                      cy='12'
                      r='10'
                      stroke='currentColor'
                      strokeWidth='4'
                      fill='none'
                    />
                    <path
                      className='opacity-75'
                      fill='currentColor'
                      d='M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z'
                    />
                  </svg>
                  Sending...
                </span>
              ) : (
                'Send Message'
              )}
            </Button>
          </form>
        )}
      </div>
    </div>
  );
}
