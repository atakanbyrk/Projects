'use client';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { RocketIcon, InfoIcon, Users2Icon } from 'lucide-react';
import Image from 'next/image';

// Enhanced team data with images (replace with real image URLs if available)
const team = [
  {
    name: 'Yusuf Ekerdiker',
    role: 'Frontend Developer',
    image: '/profile-pics/yusuf.jpeg',
    description:
      'Passionate Front-End Web Developer with a strong interest in UX/UI design. Proficient in Angular, Bootstrap and skilled in design software like Adobe Illustrator, Photoshop and Figma. Always learning and eager to stay up-to-date with the latest trends and best practices in the field.',
  },
  {
    name: 'Berke Durukan',
    role: '3D Designer',
    image: '/profile-pics/berke.jpeg',
    description:
      "Hi! I'm Berke. I am an excited young motion designer who is looking to continuously learn and become proficient in the realm of animation. Combining my education in communication design with the experience i gained in the field as a motion designer and art director means I am looking to always improve, but I have got a wealth of experience working in the field.",
  },
  {
    name: 'Atakan Albayrak',
    role: 'Fitness Expert',
    image: '/profile-pics/atakan.jpeg',
    description:
      "My name is Atakan Albayrak. I am currently pursuing a master's degree in Interactive Digital Media. Alongside my studies, I work part-time as a calisthenics and bodyweight sports coach at Bar Monkey Calisthenics and am also a certified personal trainer. Additionally, I manage a community page focused on calisthenics.",
  },
  {
    name: 'Batuhan Güçlü',
    role: 'Developer',
    image: '/profile-pics/batuhan.jpeg',
    description: 'Hey, I\'m a digital media master\'s student who loves blending creativity with tech. Whether it\'s building websites, telling stories in new ways, or exploring calisthenics, I love creating things that help people and make an impact',
  },
];

export default function AboutPage() {
  return (
    <main className='animate-fade-in mx-auto max-w-5xl px-6 py-12 text-center'>
      <h1 className='font-logo mb-4 text-4xl text-green-600 sm:text-5xl'>
        About Torqed
      </h1>
      <p className='text-muted-foreground mx-auto mb-10 max-w-2xl'>
        Torqed is your modern calisthenics guide—bridging expert-level fitness
        knowledge with interactive tools to help you move better, get stronger,
        and prevent injury.
      </p>

      <div className='mb-16 grid grid-cols-1 gap-6 sm:grid-cols-3'>
        <Card className='border-l-4 border-green-500 shadow-sm transition hover:shadow-md'>
          <CardHeader>
            <InfoIcon className='mb-2 text-green-600' />
            <CardTitle className='text-lg'>What is Calisthenics?</CardTitle>
          </CardHeader>
          <CardContent className='text-muted-foreground text-sm'>
            Calisthenics is bodyweight training that builds strength, mobility,
            and control without equipment. It&apos;s efficient, scalable, and
            accessible for all levels.
          </CardContent>
        </Card>

        <Card className='border-l-4 border-green-500 shadow-sm transition hover:shadow-md'>
          <CardHeader>
            <RocketIcon className='mb-2 text-green-600' />
            <CardTitle className='text-lg'>Why It Works</CardTitle>
          </CardHeader>
          <CardContent className='text-muted-foreground text-sm'>
            This method develops relative strength, joint health, and balance.
            From rehab to elite skills-it&apos;s practical, minimalist, and
            athletic.
          </CardContent>
        </Card>

        <Card className='border-l-4 border-green-500 shadow-sm transition hover:shadow-md'>
          <CardHeader>
            <Users2Icon className='mb-2 text-green-600' />
            <CardTitle className='text-lg'>Our Mission</CardTitle>
          </CardHeader>
          <CardContent className='text-muted-foreground text-sm'>
            We make world-class bodyweight training tools accessible for
            everyone by blending design, data, and movement science to make
            training fun and safe.
          </CardContent>
        </Card>
      </div>

      <Separator className='my-12' />

      <section className='mb-12 flex flex-col items-center'>
        <h2 className='font-logo mb-4 text-3xl text-green-600'>
          Where It All Started
        </h2>
        <p className='text-muted-foreground mb-6 max-w-xl'>
          Torqed was born from a shared frustration with injury-prone routines
          and overcomplicated advice. We wanted something better: smart,
          sustainable, science-backed training that actually works. So we built
          it.
        </p>
        <Image
          src='/landing.png'
          alt='Historical calisthenics'
          width={800}
          height={400}
          quality={100}
          className='rounded-lg border shadow-md'
          priority
        />
      </section>

      <Separator className='my-12' />

      <section className='text-center'>
        <h2 className='font-logo mb-8 text-3xl text-green-600'>
          Meet the Team
        </h2>
        <div className='grid grid-cols-1 gap-8 sm:grid-cols-2'>
          {team.map((member) => (
            <Card
              key={member.name}
              className='flex flex-col items-center border-t-2 border-green-400 p-6 transition hover:scale-105 hover:shadow-lg'
            >
              <Avatar className='mb-4 h-24 w-24 shadow-md'>
                <AvatarImage src={member.image} alt={member.name} />
                <AvatarFallback>
                  {member.name
                    .split(' ')
                    .map((n) => n[0])
                    .join('')
                    .toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <CardTitle className='mb-1 text-xl'>{member.name}</CardTitle>
              <CardDescription className='mb-2 text-green-700'>
                {member.role}
              </CardDescription>
              {member.description && (
                <CardContent className='text-muted-foreground mt-2 text-sm'>
                  {member.description}
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      </section>
    </main>
  );
}
