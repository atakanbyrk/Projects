'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { auth, db } from '@/firebase';
import { useEffect, useState } from 'react';
import { onAuthStateChanged, signOut, User } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { ThemeToggle } from './theme-toggle';
import { Button } from '@/components/ui/button';
import {
  Dumbbell,
  ClipboardList,
  HeartPulse,
  Users2,
  Menu,
  X,
  LogOut,
  LayoutDashboard,
  Contact,
} from 'lucide-react';
import {
  Sheet,
  SheetTrigger,
  SheetContent,
  SheetClose,
} from '@/components/ui/sheet';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const navLinks = [
  { href: '/exercises', label: 'Exercises', icon: Dumbbell },
  { href: '/workout-plans', label: 'Workout Plans', icon: ClipboardList },
  { href: '/health', label: 'Health', icon: HeartPulse },
  { href: '/aboutus', label: 'About Us', icon: Users2 },
  { href: '/contact', label: 'Contact Us', icon: Contact },
  /* { href: '/privacy-policy', label: 'Privacy Policy', icon: ClipboardList }, */
];

//navbar: shows site nav, user info, and a menu for logged-in users. handles user fetch from firebase, tracks scroll to close menu, and always shows the right name/photo
export default function Navbar() {
  //grabs current url path so we can style/know where we are
  const pathname = usePathname();

  //user from firebase auth
  const [user, setUser] = useState<User | null>(null);

  //user doc from firestore (for display name, profile pic, etc)
  const [userData, setUserData] = useState<{
    name?: string;
    photoURL?: string;
  } | null>(null);

  //state for hamburger/profile dropdown on mobile
  const [menuOpen, setMenuOpen] = useState(false);

  //on mount: subscribe to firebase auth. if logged in, try to fetch user's firestore doc. if no doc, fallback to auth info (google login users sometimes don't have doc yet)
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setUser(user);
      if (user) {
        const userDoc = await getDoc(doc(db, 'users', user.uid));
        if (userDoc.exists()) {
          setUserData(userDoc.data());
        } else {
          // fallback: use whatever data we get from firebase auth
          setUserData({
            name: user.displayName || user.email || 'User',
            photoURL: user.photoURL || '',
          });
        }
      } else {
        setUserData(null);
      }
    });
    return () => unsub(); //clean up on unmount
  }, []);

  //whenever menu is open, listen for scroll and close menu if user scrolls (useful for mobile)
  useEffect(() => {
    const handleScroll = () => setMenuOpen(false);
    if (menuOpen) window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [menuOpen]);

  return (
    <nav className='sticky top-0 z-50 m-2 flex items-center justify-between rounded-xl bg-emerald-950/80 px-4 py-2 shadow backdrop-blur-md dark:bg-emerald-900/80'>
      <Link
        href='/'
        className='font-logo text-xl font-bold tracking-tight text-green-400 transition hover:text-green-300 dark:text-green-300 dark:hover:text-green-200'
      >
        TorQed
      </Link>

      <ul className='font-body ml-4 hidden list-none gap-4 md:flex'>
        {navLinks.map(({ href, label }) => (
          <li key={href}>
            <Link
              href={href}
              className={`rounded px-2 py-1 underline-offset-4 transition hover:text-green-300 hover:underline dark:hover:text-green-200 ${
                pathname === href
                  ? 'font-bold text-green-400 underline dark:text-green-300'
                  : 'text-green-100 dark:text-green-200'
              }`}
            >
              {label}
            </Link>
          </li>
        ))}
      </ul>

      <div className='font-body flex items-center gap-2'>
        {/* Desktop only: theme + profile */}
        <div className='hidden items-center gap-2 md:flex'>
          <ThemeToggle />
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant='ghost' className='h-auto p-0'>
                  <div className='flex items-center gap-2'>
                    <Avatar className='h-8 w-8'>
                      <AvatarImage
                        src={userData?.photoURL || user?.photoURL || ''}
                      />
                      <AvatarFallback>
                        {userData?.name?.[0] || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <span className='hidden text-sm md:block'>
                      {userData?.name || user.email}
                    </span>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align='end'>
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href='/dashboard' className='flex items-center gap-2'>
                    <LayoutDashboard className='h-4 w-4' /> Dashboard
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => signOut(auth)}
                  className='flex items-center gap-2'
                >
                  <LogOut className='h-4 w-4' /> Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button variant='outline'>
              <Link href='/login'>Login</Link>
            </Button>
          )}
        </div>

        {/* Mobile Hamburger */}
        <div className='md:hidden'>
          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <Button
                variant='ghost'
                size='icon'
                aria-label={menuOpen ? 'Close menu' : 'Open menu'}
                className='rounded-full border border-green-400/30 shadow-sm transition hover:bg-emerald-900/40'
              >
                {menuOpen ? (
                  <X className='h-6 w-6 text-green-400 transition-transform duration-200' />
                ) : (
                  <Menu className='h-6 w-6 text-green-400 transition-transform duration-200' />
                )}
              </Button>
            </SheetTrigger>
            <SheetContent
              side='right'
              className='border-none bg-gradient-to-br from-emerald-950/90 to-emerald-900/80 p-0 text-white shadow-2xl backdrop-blur-lg'
            >
              <div className='flex h-full flex-col'>
                <div className='flex flex-col items-center gap-2 border-b border-white/10 bg-emerald-900/60 py-6 shadow-sm'>
                  <Link
                    href='/'
                    className='font-logo text-3xl font-bold tracking-tight text-green-400 transition hover:text-green-300'
                  >
                    TorQed
                  </Link>
                  {user && (
                    <div className='flex flex-col items-center gap-2'>
                      <Avatar className='h-12 w-12 shadow ring-2 ring-green-400'>
                        <AvatarImage
                          src={userData?.photoURL || user?.photoURL || ''}
                        />
                        <AvatarFallback>
                          {userData?.name?.[0] || 'U'}
                        </AvatarFallback>
                      </Avatar>
                      <div className='text-base font-semibold text-green-100'>
                        {userData?.name || user.email}
                      </div>
                      <div className='mt-2 flex w-full flex-col gap-1'>
                        <SheetClose asChild>
                          <Link
                            href='/dashboard'
                            className='flex w-full items-center gap-2 rounded-md bg-green-800/80 px-4 py-2 text-sm text-green-100 transition hover:bg-green-900 hover:text-green-300'
                          >
                            <LayoutDashboard className='h-4 w-4' /> Dashboard
                          </Link>
                        </SheetClose>
                        <SheetClose asChild>
                          <Button
                            variant='destructive'
                            className='mt-1 w-full justify-start gap-2 bg-red-600 px-4 py-2 text-sm text-white dark:bg-red-600'
                            aria-label='Logout'
                            onClick={() => signOut(auth)}
                          >
                            <LogOut className='h-4 w-4' /> Logout
                          </Button>
                        </SheetClose>
                      </div>
                    </div>
                  )}
                  {!user && (
                    <SheetClose asChild>
                      <Button
                        variant='default'
                        className='mt-2 w-32 justify-center gap-2 bg-green-700 text-white hover:bg-green-800'
                      >
                        <Link
                          href='/login'
                          className='flex w-full items-center gap-2'
                        >
                          <LogOut className='h-4 w-4' /> Login
                        </Link>
                      </Button>
                    </SheetClose>
                  )}
                </div>
                <div className='flex flex-col gap-1 px-2 py-4'>
                  <div className='font-body mt-2 flex flex-col gap-1'>
                    {navLinks.map(({ href, label, icon: Icon }) => (
                      <SheetClose asChild key={href}>
                        <Link
                          href={href}
                          className={`flex items-center gap-3 rounded-md px-3 py-2 text-base font-medium transition ${
                            pathname === href
                              ? 'bg-green-900/80 text-green-400 underline shadow'
                              : 'hover:bg-emerald-900/60 hover:text-green-300'
                          }`}
                        >
                          <Icon className='h-5 w-5' />
                          {label}
                        </Link>
                      </SheetClose>
                    ))}
                  </div>
                </div>
                <div className='mt-auto flex justify-center border-t border-white/10 bg-emerald-950/60 pt-2 pb-4'>
                  <ThemeToggle />
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
