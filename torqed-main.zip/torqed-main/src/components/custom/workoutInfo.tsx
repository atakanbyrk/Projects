export default function WorkoutInfo() {
  return (
    <div className='bg-card mb-6 rounded-lg border p-4 shadow-sm'>
      <h2 className='font-logo mb-3 text-lg text-green-600'>
        What to Expect Each Session
      </h2>

      <div className='mb-4'>
        <h3 className='font-logo mb-1 text-sm text-green-500'>Session Focus</h3>
        <ul className='font-body text-muted-foreground list-disc space-y-1 pl-5 text-xs'>
          <li>Full-body strength development</li>
          <li>One focused skill (static hold or balance)</li>
          <li>Mobility & muscle activation for that skill</li>
        </ul>
      </div>

      <div className='mb-4'>
        <h3 className='font-logo mb-1 text-sm text-green-500'>
          Warm-Up Routine
        </h3>
        <ul className='font-body text-muted-foreground list-disc space-y-1 pl-5 text-xs'>
          <li>Banded Shoulder Dislocates & Front-Lateral Raises</li>
          <li>Band Pull-Aparts</li>
          <li>Face Pull - Y Rotation</li>
          <li>Wall Slides</li>
          <li>Cat Cow</li>
          <li>Scapular Pull-Ups</li>
          <li>Wrist Rolls & Wrist Leans</li>
        </ul>
      </div>

      <div>
        <h3 className='font-logo mb-1 text-sm text-green-500'>
          Post-Workout Stretching
        </h3>
        <ul className='font-body text-muted-foreground list-disc space-y-1 pl-5 text-xs'>
          <li>Child&apos;s Pose</li>
          <li>Cobra Pose</li>
          <li>Chest T-stretch / Scorpion Chest Stretch</li>
          <li>Standing Lat Stretch</li>
          <li>Wall Angle</li>
          <li>Compression Sit</li>
          <li>Pigeon Pose</li>
        </ul>
      </div>
    </div>
  );
}
