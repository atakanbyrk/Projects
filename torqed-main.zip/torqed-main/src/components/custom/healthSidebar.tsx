//sidebar for health page, shows quick links to all sections. highlights the section you're currently reading by tracking which section is in view. also smooth scrolls when clicked
'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  StretchHorizontal,
  BrainCircuit,
  Dumbbell,
  Repeat,
  Sparkles,
} from 'lucide-react';

//all sidebar sections (these match up with the sections on the main health page)
export const sections = [
  {
    id: 'preworkout',
    title: 'Dynamic vs Static Stretching',
    icon: <StretchHorizontal size={16} className='mr-2' />,
  },
  {
    id: 'postworkout',
    title: 'Post-Workout Stretching',
    icon: <BrainCircuit size={16} className='mr-2' />,
  },
  {
    id: 'progression',
    title: 'How to Progress Skills',
    icon: <Repeat size={16} className='mr-2' />,
  },
  {
    id: 'equipment',
    title: 'Useful Training Equipment',
    icon: <Dumbbell size={16} className='mr-2' />,
  },
  {
    id: 'recap',
    title: 'Tips Recap',
    icon: <Sparkles size={16} className='mr-2' />,
  },
];

export default function HealthSidebar() {
  //activeId = id of the section currently visible in the viewport, helps us highlight the active link
  const [activeId, setActiveId] = useState<string | null>(null);

  //hook sets up intersection observer for each section on mount. whenever a section is in view, we update the activeId
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setActiveId(entry.target.id); //if user scrolls, set the active nav to that section
          }
        }
      },
      { rootMargin: '-100px 0px -70% 0px' }, //custom root margin to trigger earlier/later (bit hacky but it works for our layout)
    );

    //target all <section> tags with an id
    const targets = document.querySelectorAll('section[id]');
    targets.forEach((section) => observer.observe(section));

    return () => observer.disconnect(); //clean up observer on unmount
  }, []);

  return (
    <aside className='hidden lg:block lg:w-1/4'>
      <div className='sticky top-24'>
        <h2 className='mb-4 text-xl font-bold text-green-600'>
          Jump to Section
        </h2>
        <nav className='space-y-2 text-sm font-medium'>
          {sections.map((sec) => (
            <Link
              key={sec.id}
              href={`#${sec.id}`}
              scroll={false} //disable next/link's default scroll so we can use our custom offset
              onClick={(e) => {
                e.preventDefault();
                //when you click a link, smooth scroll to section, but offset for sticky header (80px)
                const el = document.getElementById(sec.id);
                if (el) {
                  const yOffset = -80;
                  const y =
                    el.getBoundingClientRect().top +
                    window.pageYOffset +
                    yOffset;
                  window.scrollTo({ top: y, behavior: 'smooth' });
                }
              }}
              className={`hover:bg-muted hover:text-foreground flex items-center rounded px-3 py-2 transition ${
                activeId === sec.id
                  ? 'bg-muted text-foreground font-semibold'
                  : 'text-muted-foreground'
              }`}
            >
              {sec.icon}
              {sec.title}
            </Link>
          ))}
        </nav>
      </div>
    </aside>
  );
}
