//modal dialog for adding an exercise to a custom workout plan
//lets user either pick an existing plan (or create a new one), and specify sets/reps before saving
//shows user's plans, input for sets, new plan creation in one modal

'use client';

import { useState, useEffect } from 'react';
import { useUser } from '@/lib/hooks/useUser';
import {
  createCustomWorkoutPlan,
  addExerciseToPlan,
} from '@/lib/firebase/customWorkout';
import { db } from '@/firebase';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'sonner';
import { Separator } from '../ui/separator';

// Types for incoming props and exercise/plan info
type Exercise = {
  id: string;
  name: string;
  imageUrl: string;
  description: string;
  animationUrl?: string;
};

type CustomWorkoutPlan = {
  id: string;
  name: string;
  description: string;
};

type AddToWorkoutModalProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  exercise: Exercise;
};

export default function AddToWorkoutModal({
  open,
  onOpenChange,
  exercise,
}: AddToWorkoutModalProps) {
  const { user } = useUser(); //gets current user
  const [plans, setPlans] = useState<CustomWorkoutPlan[]>([]); //user's plans from db
  const [newPlanName, setNewPlanName] = useState(''); //for new plan name input
  const [newPlanDesc, setNewPlanDesc] = useState(''); //for new plan desc input
  const [selectedPlanId, setSelectedPlanId] = useState(''); //which plan button user clicked
  const [setsReps, setSetsReps] = useState(''); //sets/reps input value

  //runs when the user logs in/changes
  //fetches all custom workout plans from firestore that belong to this user (by userId field)
  //then maps the firestore docs to our CustomWorkoutPlan objects, and updates state for UI
  /* every time the user changes (mount or login/logout), it runs
    builds a firestore query to get only this user’s workout plans
    maps docs into our own structure
    calls setPlans() so the modal can display all the user’s custom plans to pick from */
  useEffect(() => {
    const fetchPlans = async () => {
      if (!user?.uid) return;
      const q = query(
        collection(db, 'customWorkoutPlans'),
        where('userId', '==', user.uid),
      );
      const snapshot = await getDocs(q);
      const userPlans: CustomWorkoutPlan[] = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...(doc.data() as Omit<CustomWorkoutPlan, 'id'>),
      }));
      setPlans(userPlans);
    };

    fetchPlans();
  }, [user]);

  //creates new custom workout plan in firebase and immediately adds the selected exercise (with sets/reps) to it.
  //runs when user fills out new plan info and hits create
  //does a few things: first, it creates the plan in firestore, then updates local UI instantly so user sees it
  //finally, it adds the actual exercise (plus whatever sets/reps) to the plan's exercise list and closes the modal
  const handleCreateAndAdd = async () => {
    if (!user?.uid) return;

    try {
      //first creates the workout plan document, gets its id
      const planId = await createCustomWorkoutPlan(
        user.uid,
        newPlanName,
        newPlanDesc,
      );

      //immediately updates state so modal displays new plan (even before firestore catches up)
      setPlans((prev) => [
        ...prev,
        {
          id: planId,
          name: newPlanName,
          description: newPlanDesc,
        },
      ]);

      //now adds the selected exercise with sets/reps to that plan in firestore
      await addExerciseToPlan(planId, { ...exercise, setsReps });

      //user feedback
      toast.success(`${exercise.name} added to new workout plan!`);
      onOpenChange(false); //close modal
    } catch (err: unknown) {
      //shows error message if anything fails
      if (err instanceof Error) {
        toast.error(err.message);
      } else {
        toast.error('Something went wrong');
      }
    }
  };

  //adds the exercise to an already existing plan
  const handleAddToExisting = async () => {
    if (!selectedPlanId) return;

    try {
      await addExerciseToPlan(selectedPlanId, { ...exercise, setsReps });
      toast.success(`${exercise.name} added to workout plan!`);
      onOpenChange(false);
    } catch (err: unknown) {
      if (err instanceof Error) {
        toast.error(err.message);
      } else {
        toast.error('Something went wrong');
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className='max-w-[95vw]'>
        <DialogHeader>
          <DialogTitle className='font-logo mb-1 text-center text-2xl text-green-700'>
            Add to Workout Plan
          </DialogTitle>
        </DialogHeader>

        {/* Section: Add to Existing Plan */}
        <div>
          <h4 className='font-logo mb-2 text-base text-green-600'>
            Add to Existing Plan
          </h4>
          <div className='mb-2 flex flex-wrap gap-2'>
            {plans.length === 0 ? (
              <span className='font-logo text-muted-foreground text-sm'>
                No plans yet
              </span>
            ) : (
              plans.map((plan) => (
                <Button
                  key={plan.id}
                  variant={selectedPlanId === plan.id ? 'default' : 'outline'}
                  onClick={() => setSelectedPlanId(plan.id)}
                  className={`font-body min-w-[120px] text-sm ${
                    selectedPlanId === plan.id
                      ? 'ring-2 ring-green-600'
                      : 'hover:bg-green-50 dark:hover:bg-green-900'
                  }`}
                >
                  {plan.name}
                </Button>
              ))
            )}
          </div>
          <Input
            placeholder='e.g. 3x5, max hold'
            value={setsReps}
            onChange={(e) => setSetsReps(e.target.value)}
            className='font-body mb-2'
          />
          <Button
            onClick={handleAddToExisting}
            disabled={!selectedPlanId || !setsReps}
            className='font-logo w-full bg-green-600 text-white transition hover:bg-green-700 disabled:bg-green-200 disabled:text-green-800'
          >
            Add to Selected Plan
          </Button>
        </div>

        <Separator className='mt-4 mb-2' />

        {/* Section: Create New Plan */}
        <div>
          <h4 className='font-logo mb-2 text-base text-green-600'>
            Or Create New Plan
          </h4>
          <div className='mb-2 space-y-2'>
            <Input
              placeholder='Plan name'
              value={newPlanName}
              onChange={(e) => setNewPlanName(e.target.value)}
              className='font-body'
            />
            <Input
              placeholder='Description'
              value={newPlanDesc}
              onChange={(e) => setNewPlanDesc(e.target.value)}
              className='font-body'
            />
            <Input
              placeholder='Sets/reps (e.g. 3x5, max hold)'
              value={setsReps}
              onChange={(e) => setSetsReps(e.target.value)}
              className='font-body'
            />
          </div>
          <Button
            onClick={handleCreateAndAdd}
            disabled={!newPlanName || !newPlanDesc || !setsReps}
            className='font-logo w-full bg-green-700 text-white transition hover:bg-green-800 disabled:bg-green-200 disabled:text-green-800'
          >
            Create Plan &amp; Add
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
