'use client';

import { Moon, Sun } from 'lucide-react';
import { useTheme } from 'next-themes';
import { Button } from '@/components/ui/button';
import { useEffect, useRef, useState } from 'react';

export function ThemeToggle() {
  const { setTheme, theme } = useTheme();
  const hasMounted = useRef(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    hasMounted.current = true;
    setMounted(true);
  }, []);

  if (!mounted) return null;

  return (
    <Button
      onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      aria-label='Toggle theme'
    >
      {theme === 'dark' ? (
        <Sun className='h-5 w-5' />
      ) : (
        <Moon className='h-5 w-5' />
      )}
    </Button>
  );
}
