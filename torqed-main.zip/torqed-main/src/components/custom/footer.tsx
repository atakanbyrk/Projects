import Link from 'next/link';
import { Github, Instagram } from 'lucide-react';

export default function Footer() {
  return (
    <footer className='mt-16 w-full border-t py-6 text-center'>
      <div className='font-body text-muted-foreground flex flex-col items-center gap-2 text-xs sm:text-sm'>
        <div>
          &copy; {new Date().getFullYear()} TorQed &middot;
          <Link
            href='/privacy-policy'
            className='ml-2 underline hover:text-green-600'
          >
            Privacy Policy
          </Link>
          <span className='mx-2'>&middot;</span>
          <Link
            href='/terms'
            className='underline hover:text-green-600'
          >
            Terms of Service
          </Link>
          <span className='mx-2'>&middot;</span>
          <Link href='/contact' className='underline hover:text-green-600'>
            Contact
          </Link>
        </div>
        <div className='mt-2 flex gap-4'>
          <Link
            href='https://github.com/yusufekerdiker/torqed'
            target='_blank'
            rel='noopener noreferrer'
            aria-label='GitHub'
          >
            <Github className='h-5 w-5 transition hover:text-green-600' />
          </Link>
          <Link
            href='https://www.instagram.com/torqedcalisthenics/'
            target='_blank'
            rel='noopener noreferrer'
            aria-label='Instagram'
          >
            <Instagram className='h-5 w-5 transition hover:text-green-600' />
          </Link>
        </div>
      </div>
    </footer>
  );
}
