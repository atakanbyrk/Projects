//renders a 3D .glb model viewer using react-three-fiber + drei
//mainly used to display animated calisthenics models on exercise cards/pages
//wraps a <Canvas> with lights, controls, and fallback loader
//loads and plays model animation if present
'use client';

import { Canvas, useFrame, useLoader } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import { Suspense, useEffect, useRef } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { Html } from '@react-three/drei';

type Props = {
  url: string; //url to the .glb model
};

//loads the actual .glb file and plays the first animation if it exists
function Model({ url }: Props) {
  //grab model with threejs GLTFLoader, cache by url
  const gltf = useLoader(GLTFLoader, url);

  //used for animation (if model has one)
  const mixer = useRef<THREE.AnimationMixer | null>(null);

  //if model contains any animation clips, play the first one on mount
  useEffect(() => {
    if (gltf.animations.length > 0) {
      mixer.current = new THREE.AnimationMixer(gltf.scene);
      const action = mixer.current.clipAction(gltf.animations[0]);
      action.play();
    }
  }, [gltf]);

  //runs animation updates on every frame (if mixer present)
  useFrame((_, delta) => {
    mixer.current?.update(delta);
  });

  //render model (move it down a little so it's centered in viewer)
  return <primitive object={gltf.scene} position={[0, -1.25, 0]} />;
}

//main 3d viewer - sets up canvas, lights, bg color, orbit controls etc.
export default function GLBViewer({ url }: Props) {
  return (
    <div className='relative m-0 h-full max-h-[700px] min-h-[300px] w-full overflow-hidden rounded bg-transparent p-0 three-canvas-fix'>
      {/* Canvas is the actual 3D scene. camera set a bit far out for model */}
      <Canvas camera={{ position: [0, 0, 5], fov: 45 }}>
        {/* dark background color, not default white */}
        <color attach='background' args={['rgb(24,24,24)']} />

        {/* soft ambient + several directional lights for shadow/shape */}
        <ambientLight intensity={0.8} />
        <directionalLight position={[4, 4, 4]} intensity={0.9} />
        <directionalLight position={[-2, 5, 2]} intensity={0.5} />
        <directionalLight position={[-0, 2, 7]} intensity={1} />

        {/* Suspense fallback: show loading text while model loads */}
        <Suspense
          fallback={
            <Html>
              <div className='text-sm text-gray-400'>Loading...</div>
            </Html>
          }
        >
          {/* Loads and renders the actual .glb model */}
          <Model url={url} />
        </Suspense>

        {/* allow user to rotate, pan, zoom model */}
        <OrbitControls enableZoom={true} />
      </Canvas>
    </div>
  );
}
