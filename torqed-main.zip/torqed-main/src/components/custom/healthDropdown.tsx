//dropdown menu for health page – only shows up on mobile.
//lets users jump to different sections quickly by scrolling there

'use client';
import { sections } from './healthSidebar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function HealthDropdown() {
  //renders a select dropdown with all section ids/titles.
  //on change, scrolls the page to the right section using its id.
  return (
    <div className='mb-6 lg:hidden'>
      {/* label for accessibility */}
      <label
        htmlFor='section-select'
        className='mb-2 block text-sm font-semibold text-green-600'
      >
        Jump to Section
      </label>
      <Select
        //when dropdown changes, find the dom element by id and scroll to it
        onValueChange={(val) => {
          const el = document.getElementById(val);
          if (el) {
            // Get offset of sticky header/dropdown. Change 60 to whatever px you need
            const yOffset = -60;
            const y = el.getBoundingClientRect().top + window.scrollY + yOffset;
            window.scrollTo({ top: y, behavior: 'smooth' });
          }
        }}
      >
        <SelectTrigger className='w-full'>
          <SelectValue placeholder='Jump to Section' />
        </SelectTrigger>
        <SelectContent>
          {/* render options for all sections (from healthSidebar.js) */}
          {sections.map(({ id, title }) => (
            <SelectItem key={id} value={id}>
              {title}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
