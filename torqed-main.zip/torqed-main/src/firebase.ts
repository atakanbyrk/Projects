//handles all the firebase config/init for the whole app
//makes sure we only create ONE app instance (prevents errors with hot reload/dev)
//exports firebase auth, firestore, and storage for easy import everywhere
import { initializeApp, getApps } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { firebaseConfig } from "./firebaseConfig";

//don't create new app if already initialized, (dev server can re-import files a lot)
const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);