// script to seed or update the global workout plans in Firestore
// takes global_workout_plans.json and writes each level (beginner/intermediate/advanced)
// as a doc in the globalWorkoutPlans collection
// safe to rerun: uses merge:true so only updates changed fields

import { initializeApp } from 'firebase/app';
import { getFirestore, doc, setDoc } from 'firebase/firestore';
import { firebaseConfig } from './src/firebaseConfig';
import plans from './global_workout_plans.json' assert { type: 'json' };

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

//type for workout plans JSON structure (make sure your JSON matches this)
type WorkoutPlan = {
  level: string; // 'beginner', 'intermediate', 'advanced'
  days: {
    day: number;
    exercises: {
      id: string;
      name?: string;
      sets?: string;
      note?: string;
    }[];
  }[];
};

async function seed() {
  //parse and typecast data from the imported json
  const workoutPlans: WorkoutPlan[] = plans;

  for (const plan of workoutPlans) {
    //for each plan level: upload or update doc in 'globalWorkoutPlans' (doc id = level)
    const ref = doc(db, 'globalWorkoutPlans', plan.level);
    await setDoc(
      ref,
      {
        level: plan.level,
        days: plan.days,
      },
      { merge: true }, //only patch changes, don't nuke extra fields
    );

    console.log(`Uploaded: ${plan.level}`);
  }

  console.log('Global workout plans seeding complete!');
}

//run the seeder, show errors in console
seed().catch(console.error);
