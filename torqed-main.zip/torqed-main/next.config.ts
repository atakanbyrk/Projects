/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: [], // Add all domains you need
  },
};

module.exports = nextConfig;