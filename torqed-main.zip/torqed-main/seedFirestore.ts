// script for seeding/updating exercises in firestore from a local json file
// - reads skills_exercises.json
// - for each exercise: uploads (or updates) doc in 'exercises' collection (by id)
// - will only change updated fields (merge: true), so safe to rerun if you tweak stuff

import { initializeApp } from 'firebase/app';
import { getFirestore, setDoc, doc } from 'firebase/firestore';
import { firebaseConfig } from './src/firebaseConfig';
import data from './skills_exercises.json' assert { type: 'json' };

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

//interface for our exercises json objects
type Exercise = {
  id: string;
  name: string;
  level: string;
  target_area: string[]; // raw field from JSON
  description: string;
  difficulty: number;
  animationUrl: string;
  imageUrl: string;
};

async function seed() {
  const exercises: Exercise[] = data;

  for (const ex of exercises) {
    //for every exercise: create or update doc by id
    await setDoc(
      doc(db, 'exercises', ex.id),
      {
        name: ex.name,
        level: ex.level,
        musclesWorked: ex.target_area, // renaming field to fit DB schema
        description: ex.description,
        difficulty: ex.difficulty,
        animationUrl: ex.animationUrl || '',
        imageUrl: ex.imageUrl || '',
      },
      { merge: true }, //don't overwrite whole doc, just update changed fields
    );
    console.log(`Uploaded: ${ex.name}`);
  }

  console.log('Seeding complete!');
}

//run seeder, catch and log any errors
seed().catch(console.error);
